-- dumping schema
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.5 (Ubuntu 15.5-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_net; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_net" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_net"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "pg_net" IS 'Async HTTP';


--
-- Name: pgsodium; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgsodium";


--
-- Name: EXTENSION "pgsodium"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "pgsodium" IS 'Pgsodium is a modern cryptography library for Postgres.';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "pg_graphql" IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: pgjwt; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgjwt" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgjwt"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "pgjwt" IS 'JSON Web Token API for Postgresql';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "postgis" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "postgis"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "postgis" IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner:
--

-- COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: app_permissions; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."app_permissions" AS ENUM (
    'operational_event_read',
    'operational_event_create'
);


ALTER TYPE "public"."app_permissions" OWNER TO "supabase_admin";

--
-- Name: app_roles; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."app_roles" AS ENUM (
    'user',
    'subcom_agent',
    'com_admin',
    'admin'
);


ALTER TYPE "public"."app_roles" OWNER TO "supabase_admin";

--
-- Name: group_chat_type; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."group_chat_type" AS ENUM (
    'chat',
    'request_consumable',
    'request_durable',
    'request_skill'
);


ALTER TYPE "public"."group_chat_type" OWNER TO "supabase_admin";

--
-- Name: message_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE "public"."message_type" AS ENUM (
    'resource_request',
    'text',
    'resource_removed'
);


ALTER TYPE "public"."message_type" OWNER TO "postgres";

--
-- Name: TYPE "message_type"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE "public"."message_type" IS 'type of message, for the chat inbox colors';


--
-- Name: messageurgency; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE "public"."messageurgency" AS ENUM (
    'normal',
    'important',
    'urgent',
    'emergency'
);


ALTER TYPE "public"."messageurgency" OWNER TO "postgres";

--
-- Name: operational_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE "public"."operational_status" AS ENUM (
    'emergency',
    'test',
    'normal'
);


ALTER TYPE "public"."operational_status" OWNER TO "postgres";

--
-- Name: poi_category; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."poi_category" AS ENUM (
    'emergency_safety',
    'medical',
    'education',
    'community_civic',
    'nature_outdoor',
    'utility',
    'business_economic',
    'personal_other'
);


ALTER TYPE "public"."poi_category" OWNER TO "supabase_admin";

--
-- Name: priority; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."priority" AS ENUM (
    'low',
    'medium',
    'high'
);


ALTER TYPE "public"."priority" OWNER TO "supabase_admin";

--
-- Name: request_scope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE "public"."request_scope" AS ENUM (
    'nearby',
    'neighbors'
);


ALTER TYPE "public"."request_scope" OWNER TO "postgres";

--
-- Name: TYPE "request_scope"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE "public"."request_scope" IS 'ask based on current location or nearest households for a given request';


--
-- Name: reservation_status; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."reservation_status" AS ENUM (
    'pending',
    'accepted',
    'rejected',
    'released',
    'expired',
    'tentative'
);


ALTER TYPE "public"."reservation_status" OWNER TO "supabase_admin";

--
-- Name: sharing_scopes; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE "public"."sharing_scopes" AS ENUM (
    'cluster',
    'neighborhood',
    'everyone'
);


ALTER TYPE "public"."sharing_scopes" OWNER TO "postgres";

--
-- Name: TYPE "sharing_scopes"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TYPE "public"."sharing_scopes" IS 'scopes for sharing resources';


--
-- Name: unit; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."unit" AS ENUM (
    'Gallons',
    'People',
    'Servings',
    'Unknown'
);


ALTER TYPE "public"."unit" OWNER TO "supabase_admin";

--
-- Name: TYPE "unit"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TYPE "public"."unit" IS 'measurement/quantity units';


--
-- Name: visibility_scope; Type: TYPE; Schema: public; Owner: supabase_admin
--

CREATE TYPE "public"."visibility_scope" AS ENUM (
    'neighborhood',
    'cluster',
    'household',
    'private'
);


ALTER TYPE "public"."visibility_scope" OWNER TO "supabase_admin";

--
-- Name: TYPE "visibility_scope"; Type: COMMENT; Schema: public; Owner: supabase_admin
--

COMMENT ON TYPE "public"."visibility_scope" IS 'visibility scopes for points of interest';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: user_resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."user_resources" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "resource_id" "uuid",
    "quantity" integer,
    "notes" character varying,
    "created_at" timestamp without time zone NOT NULL,
    "updated_at" timestamp without time zone NOT NULL,
    "sharing_scope" "public"."sharing_scopes" DEFAULT 'cluster'::"public"."sharing_scopes" NOT NULL,
    "sharing_scope_emergency" "public"."sharing_scopes" DEFAULT 'neighborhood'::"public"."sharing_scopes" NOT NULL
);


ALTER TABLE "public"."user_resources" OWNER TO "postgres";

--
-- Name: COLUMN "user_resources"."sharing_scope"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."user_resources"."sharing_scope" IS 'sharing scope of resource during normal times';


--
-- Name: COLUMN "user_resources"."sharing_scope_emergency"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."user_resources"."sharing_scope_emergency" IS 'sharing scope for resource during emergency';


--
-- Name: add_user_resource("uuid", "uuid", integer, character varying, "public"."sharing_scopes", "public"."sharing_scopes"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying DEFAULT NULL::character varying, "p_sharing_scope" "public"."sharing_scopes" DEFAULT 'cluster'::"public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes" DEFAULT 'neighborhood'::"public"."sharing_scopes") RETURNS "public"."user_resources"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public', 'extensions'
    AS $$declare
  v_row public.user_resources;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'Quantity must be greater than 0';
  end if;
  insert into public.user_resources (
    id,
    user_id,
    resource_id,
    quantity,
    notes,
    created_at,
    updated_at,
    sharing_scope,
    sharing_scope_emergency
  )
  values (
    extensions.gen_random_uuid(),
    p_user_id,
    p_resource_id,
    p_quantity,
    p_notes,
    now(),
    now(),
    p_sharing_scope,
    p_sharing_scope_emergency
  )
  on conflict (user_id, resource_id, sharing_scope, sharing_scope_emergency)
  do update
  set
    quantity = public.user_resources.quantity + excluded.quantity,
    notes = coalesce(excluded.notes, public.user_resources.notes),
    updated_at = now()
  returning * into v_row;

  return v_row;
end;$$;


ALTER FUNCTION "public"."add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying, "p_sharing_scope" "public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes") OWNER TO "supabase_admin";

--
-- Name: authorize("public"."app_permissions"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."authorize"("requested_permission" "public"."app_permissions") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
  DECLARE
      bind_permissions int;
      user_role public.app_roles;
  BEGIN
      SELECT (auth.jwt() ->> 'user_role')::public.app_roles INTO user_role;

      SELECT count(*)
      INTO bind_permissions
      FROM public.role_permissions
      WHERE role_permissions.permission = requested_permission
        AND role_permissions.role = user_role;

      RETURN bind_permissions > 0;
  END;
  $$;


ALTER FUNCTION "public"."authorize"("requested_permission" "public"."app_permissions") OWNER TO "supabase_admin";

--
-- Name: custom_access_token("jsonb"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE OR REPLACE FUNCTION "public"."custom_access_token"("event" "jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
    DECLARE
      claims jsonb;
      user_role public.app_roles;
    BEGIN
      -- Fetch the user role from the user_roles table
      SELECT role INTO user_role
      FROM public.user_roles
      WHERE user_profile_id = (event->>'user_id')::uuid;

      claims := event->'claims';

      -- Set or remove the user_role claim based on the presence of user_role
      IF user_role IS NOT NULL THEN
        claims := jsonb_set(claims, '{user_role}', to_jsonb(user_role));
      ELSE
        claims := jsonb_set(claims, '{user_role}', 'null');
      END IF;

      -- Update the 'claims' object in the original event
      event := jsonb_set(event, '{claims}', claims);

      -- Return the modified event
      RETURN event;
    END;
  $$;


ALTER FUNCTION "public"."custom_access_token"("event" "jsonb") OWNER TO "postgres";

--
-- Name: delete_checklist_step_cascade(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE OR REPLACE FUNCTION "public"."delete_checklist_step_cascade"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
  BEGIN
      DELETE FROM checklist_steps_states
      WHERE checklist_steps_order_id IN (
          SELECT id
          FROM checklist_steps_orders
          WHERE checklist_step_id = OLD.id
      );

      DELETE FROM checklist_steps_orders
      WHERE checklist_step_id = OLD.id;

      RETURN OLD;
  END;
  $$;


ALTER FUNCTION "public"."delete_checklist_step_cascade"() OWNER TO "postgres";

--
-- Name: delete_user("uuid"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."delete_user"("user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
begin
  delete from auth.users where id = user_id;
end;
$$;


ALTER FUNCTION "public"."delete_user"("user_id" "uuid") OWNER TO "supabase_admin";

--
-- Name: find_direct_group_between_profiles("uuid", "uuid"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid") RETURNS "uuid"
    LANGUAGE "sql"
    AS $$
  select gm.group_id
  from group_members gm
  group by gm.group_id
  having
    count(*) = 2
    and count(*) filter (where gm.profile_id = p_profile_a) = 1
    and count(*) filter (where gm.profile_id = p_profile_b) = 1
  limit 1;
$$;


ALTER FUNCTION "public"."find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid") OWNER TO "supabase_admin";

--
-- Name: get_nearest_resource_suppliers_by_current_location("uuid", "uuid", double precision, double precision, boolean); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean DEFAULT false) RETURNS TABLE("profile_id" "uuid", "people_id" "uuid", "household_id" "uuid", "user_resource_id" "uuid", "available_quantity" bigint, "distance_meters" double precision)
    LANGUAGE "sql"
    SET "search_path" TO 'public', 'extensions'
    AS $$
with origin as (
  select extensions.ST_SetSRID(
    extensions.ST_MakePoint(
      p_longitude::float8,
      p_latitude::float8
    ),
    4326
  ) as geom
),
requester as (
  select h.cluster_id
  from public.people p
  left join public.people_groups pg on pg.people_id = p.id
  left join public.households h on h.id = pg.household_id
  where p.user_profile_id = p_requester_profile_id
),
own_reservations as (
  select
    rr.user_resource_id,
    sum(rr.quantity) as reserved_quantity
  from public.resource_reservations rr
  where rr.requester_profile_id = p_requester_profile_id
    and rr.status in ('pending', 'tentative')
  group by rr.user_resource_id
)
select
  candidate_up.id as profile_id,
  candidate_p.id as people_id,
  candidate_pg.household_id,
  ur.id as user_resource_id,
  (ur.quantity - coalesce(orr.reserved_quantity, 0))::bigint as available_quantity,
  extensions.ST_Distance(
    candidate_h.geom::extensions.geography,
    o.geom::extensions.geography
  ) as distance_meters
from public.user_resources ur
join public.user_profiles candidate_up
  on candidate_up.id = ur.user_id
join public.people candidate_p
  on candidate_p.user_profile_id = candidate_up.id
join public.people_groups candidate_pg
  on candidate_pg.people_id = candidate_p.id
join public.households candidate_h
  on candidate_h.id = candidate_pg.household_id
left join own_reservations orr
  on orr.user_resource_id = ur.id
cross join origin o
cross join requester rq
where ur.resource_id = p_resource_id
  and (ur.quantity - coalesce(orr.reserved_quantity, 0)) > 0
  and candidate_up.id <> p_requester_profile_id
  and candidate_h.geom is not null
  and (
    (case when p_is_emergency then ur.sharing_scope_emergency else ur.sharing_scope end) <> 'cluster'
    or candidate_h.cluster_id = rq.cluster_id
  )
order by candidate_h.geom <-> o.geom;
$$;


ALTER FUNCTION "public"."get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean) OWNER TO "supabase_admin";

--
-- Name: get_nearest_resource_suppliers_by_household("uuid", "uuid", boolean); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean DEFAULT false) RETURNS TABLE("profile_id" "uuid", "people_id" "uuid", "given_name" character varying, "household_id" "uuid", "user_resource_id" "uuid", "available_quantity" integer, "distance_meters" double precision)
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public', 'extensions'
    AS $$
BEGIN
  RETURN QUERY

  with requester as (
    select
      up.id as profile_id,
      p.id as people_id,
      pg.household_id,
      h.geom,
      h.cluster_id
    from user_profiles up
    join people p
      on p.user_profile_id = up.id
    join people_groups pg
      on pg.people_id = p.id
    join households h
      on h.id = pg.household_id
    where up.id = p_requester_profile_id
  ),
  own_reservations as (
    select
      rr.user_resource_id,
      sum(rr.quantity) as reserved_quantity
    from public.resource_reservations rr
    where rr.requester_profile_id = p_requester_profile_id
      and rr.status in ('pending', 'tentative')
    group by rr.user_resource_id
  )
  select
    candidate_up.id as profile_id,
    candidate_p.id as people_id,
    candidate_p.given_name as given_name,
    candidate_pg.household_id as household_id,
    ur.id as user_resource_id,
    (ur.quantity - coalesce(orr.reserved_quantity, 0))::integer as available_quantity,
    ST_Distance(candidate_h.geom::geography, rq.geom::geography) as distance_meters
  from user_resources ur
  join user_profiles candidate_up
    on candidate_up.id = ur.user_id
  join people candidate_p
    on candidate_p.user_profile_id = candidate_up.id
  join people_groups candidate_pg
    on candidate_pg.people_id = candidate_p.id
  join households candidate_h
    on candidate_h.id = candidate_pg.household_id
  left join own_reservations orr
    on orr.user_resource_id = ur.id
  cross join requester rq
  where ur.resource_id = p_resource_id
    and (ur.quantity - coalesce(orr.reserved_quantity, 0)) > 0
    and candidate_up.id <> p_requester_profile_id
    and candidate_pg.household_id <> rq.household_id
    and candidate_h.geom is not null
    and rq.geom is not null
    and (
      (case when p_is_emergency then ur.sharing_scope_emergency else ur.sharing_scope end) <> 'cluster'
      or candidate_h.cluster_id = rq.cluster_id
    )
  order by candidate_h.geom <-> rq.geom;
END;
$$;


ALTER FUNCTION "public"."get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean) OWNER TO "supabase_admin";

--
-- Name: get_next_group_name("text"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."get_next_group_name"("p_base_name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $_$declare
  v_name text;
  v_max_suffix int;
begin
  if not exists (
    select 1
    from groups
    where name = p_base_name
  ) then
    return p_base_name;
  end if;

  select coalesce(
    max(
      nullif(
        substring(name from '\((\d+)\)$'),
        ''
      )::int
    ),
    0
  )
  into v_max_suffix
  from groups
  where name = p_base_name
     or name ~ ('^' || regexp_replace(p_base_name, '([.[\]{}()*+?^$|\\-])', '\\\1', 'g') || ' \(\d+\)$');

  return p_base_name || ' (' || (v_max_suffix + 1) || ')';
end;$_$;


ALTER FUNCTION "public"."get_next_group_name"("p_base_name" "text") OWNER TO "supabase_admin";

--
-- Name: get_unread_count("uuid", "uuid"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid") RETURNS integer
    LANGUAGE "sql"
    AS $$
  select count(*) as unread_count
  from messages m
  left join message_reads mr
    on mr.message_id = m.id
   and mr.profile_id = p_profile_id
  where m.to_id = p_group_id
    and mr.message_id is null
    and m.from_id <> p_profile_id;
  $$;


ALTER FUNCTION "public"."get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid") OWNER TO "supabase_admin";

--
-- Name: point_of_interests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."point_of_interests" (
    "id" "uuid" NOT NULL,
    "name" character varying NOT NULL,
    "address" character varying NOT NULL,
    "geom" "extensions"."geometry"(Point),
    "point_type_name" character varying NOT NULL,
    "user_id" "uuid",
    "visibility_scope" "public"."visibility_scope" DEFAULT 'private'::"public"."visibility_scope" NOT NULL,
    "cluster_id" "uuid",
    "household_id" "uuid",
    "expires_at" timestamp with time zone,
    "notes" "text"
);


ALTER TABLE "public"."point_of_interests" OWNER TO "postgres";

--
-- Name: get_visible_points_of_interest("uuid"); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."get_visible_points_of_interest"("p_requester_profile_id" "uuid") RETURNS SETOF "public"."point_of_interests"
    LANGUAGE "sql"
    SET "search_path" TO 'public', 'extensions'
    AS $$
    with requester as (
      select pg.household_id, h.cluster_id
      from public.user_profiles up
      join public.people p on p.user_profile_id = up.id
      left join public.people_groups pg on pg.people_id = p.id
      left join public.households h on h.id = pg.household_id
      where up.id = p_requester_profile_id
    )
    select poi.*
    from public.point_of_interests poi
    cross join requester rq
    where (poi.expires_at is null or poi.expires_at > now())
      and (
        poi.visibility_scope = 'neighborhood'
        or (poi.visibility_scope = 'private' and poi.user_id = p_requester_profile_id)
        or (poi.visibility_scope = 'household' and poi.household_id = rq.household_id)
        or (poi.visibility_scope = 'cluster' and poi.cluster_id = rq.cluster_id)
      );
  $$;


ALTER FUNCTION "public"."get_visible_points_of_interest"("p_requester_profile_id" "uuid") OWNER TO "supabase_admin";

--
-- Name: handle_reservation_status_change(); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."handle_reservation_status_change"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
  DECLARE
    v_is_skill BOOLEAN;
  BEGIN
    IF NEW.status = 'accepted' AND OLD.status != 'accepted' THEN
      SELECT EXISTS (
        SELECT 1 FROM user_resources_view
        WHERE id = NEW.user_resource_id
        AND rt_name = 'Skill'
      ) INTO v_is_skill;

      IF NOT v_is_skill THEN
        UPDATE user_resources
        SET quantity = quantity - NEW.quantity
        WHERE id = NEW.user_resource_id;
      END IF;

    ELSIF NEW.status IN ('released', 'rejected', 'tentative') AND OLD.status = 'accepted' THEN
      SELECT EXISTS (
        SELECT 1 FROM user_resources_view
        WHERE id = NEW.user_resource_id
        AND rt_name = 'Skill'
      ) INTO v_is_skill;

      IF NOT v_is_skill THEN
        UPDATE user_resources
        SET quantity = quantity + OLD.quantity
        WHERE id = NEW.user_resource_id;
      END IF;
    END IF;

    RETURN NEW;
  END;
  $$;


ALTER FUNCTION "public"."handle_reservation_status_change"() OWNER TO "supabase_admin";

--
-- Name: insert_checklist_steps_state_for_all_users(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE OR REPLACE FUNCTION "public"."insert_checklist_steps_state_for_all_users"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
  DECLARE
      user_record RECORD;
  BEGIN
      -- Loop through each user in the user_profiles table
      FOR user_record IN SELECT id FROM public.user_profiles LOOP
          -- Insert a new row into checklist_steps_states for each user
          INSERT INTO public.checklist_steps_states (id, checklist_steps_order_id, user_profile_id, is_completed)
          VALUES (gen_random_uuid(), NEW.id, user_record.id, FALSE);
      END LOOP;

      RETURN NEW;
  END;
  $$;


ALTER FUNCTION "public"."insert_checklist_steps_state_for_all_users"() OWNER TO "postgres";

--
-- Name: insert_user_checklists_for_all_users(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE OR REPLACE FUNCTION "public"."insert_user_checklists_for_all_users"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
  DECLARE
      user_record RECORD;
  BEGIN
      -- Loop through each user in the user_profiles table
      FOR user_record IN SELECT id FROM public.user_profiles LOOP
          -- Insert a new row into user_checklists for each user
          INSERT INTO public.user_checklists (id, checklist_id, user_profile_id)
          VALUES (gen_random_uuid(), NEW.id, user_record.id);
      END LOOP;

      RETURN NEW;
  END;
  $$;


ALTER FUNCTION "public"."insert_user_checklists_for_all_users"() OWNER TO "postgres";

--
-- Name: invalidate_signup_code("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE OR REPLACE FUNCTION "public"."invalidate_signup_code"("input_code" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    new_code TEXT;
BEGIN
    -- Generate new code using first 7 characters of UUID hex, capitalized
    new_code := UPPER(LEFT(REPLACE(gen_random_uuid()::TEXT, '-', ''), 7));

    -- Update signup_codes table with the new code
    UPDATE signup_codes
    SET code = new_code
    WHERE code = input_code;

    -- Return the newly generated code
    RETURN new_code;
END;
$$;


ALTER FUNCTION "public"."invalidate_signup_code"("input_code" "text") OWNER TO "postgres";

--
-- Name: requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."requests" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "resource_id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "quantity" integer DEFAULT 0 NOT NULL,
    "notes" "text",
    "request_scope" "public"."request_scope" DEFAULT 'neighbors'::"public"."request_scope" NOT NULL,
    "requester_profile_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "expires_at" timestamp with time zone,
    "hours_needed" integer,
    "distance_meters" double precision,
    "supplier_profile_id" "uuid",
    "urgency" "public"."messageurgency" DEFAULT 'normal'::"public"."messageurgency" NOT NULL
);


ALTER TABLE "public"."requests" OWNER TO "postgres";

--
-- Name: COLUMN "requests"."requester_profile_id"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."requests"."requester_profile_id" IS 'user who requested';


--
-- Name: reserve_request_candidate("uuid", integer, "public"."request_scope", "uuid", "uuid", "uuid", "text", double precision); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text" DEFAULT NULL::"text", "p_distance_meters" double precision DEFAULT NULL::double precision) RETURNS "public"."requests"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public', 'extensions'
    AS $$declare
  v_request public.requests;
  v_user_resource public.user_resources;
  v_own_reserved_quantity integer;
  v_available_quantity integer;
  v_grantable_quantity integer;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'Quantity must be greater than 0';
  end if;

  perform pg_advisory_xact_lock(
    ('x' || substr(md5('user_resource_reservation:' || p_user_resource_id::text), 1, 16))::bit(64)::bigint
  );

  select *
  into v_user_resource
  from public.user_resources ur
  where ur.id = p_user_resource_id
    and ur.resource_id = p_resource_id
    and ur.user_id = p_supplier_profile_id
  for update;

  if not found then
    raise exception 'Selected user_resource row not found for supplier/resource';
  end if;

  select coalesce(sum(rr.quantity), 0)::integer
  into v_own_reserved_quantity
  from public.resource_reservations rr
  where rr.user_resource_id = p_user_resource_id
    and rr.requester_profile_id = p_requester_profile_id
    and rr.status in ('pending', 'tentative');

  v_available_quantity := coalesce(v_user_resource.quantity, 0);

  v_grantable_quantity := least(
    p_quantity,
    greatest(v_available_quantity - v_own_reserved_quantity, 0)
  );

  if v_grantable_quantity <= 0 then
    raise exception 'No available inventory remains for this candidate row';
  end if;

  insert into public.requests (
    resource_id,
    quantity,
    notes,
    request_scope,
    requester_profile_id,
    supplier_profile_id,
    distance_meters
  )
  values (
    p_resource_id,
    v_grantable_quantity,
    p_notes,
    p_request_scope,
    p_requester_profile_id,
    p_supplier_profile_id,
    p_distance_meters
  )
  returning * into v_request;

  insert into public.resource_reservations (
    id,
    user_resource_id,
    request_id,
    requester_profile_id,
    quantity,
    status,
    created_at,
    updated_at
  )
  values (
    extensions.gen_random_uuid(),
    p_user_resource_id,
    v_request.id,
    p_requester_profile_id,
    v_grantable_quantity,
    'pending',
    now(),
    now()
  );

  return v_request;
end;$$;


ALTER FUNCTION "public"."reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text", "p_distance_meters" double precision) OWNER TO "supabase_admin";

--
-- Name: reserve_request_candidate_v2("uuid", integer, "public"."request_scope", "uuid", "uuid", "uuid", timestamp without time zone, "text", double precision); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text" DEFAULT NULL::"text", "p_distance_meters" double precision DEFAULT NULL::double precision) RETURNS "public"."requests"
    LANGUAGE "plpgsql"
    AS $$-- 4
  declare
  v_request requests;
  v_user_resource user_resources;
  v_own_reserved_quantity integer;
  v_available_quantity integer;
  v_grantable_quantity integer;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'Quantity must be greater than 0';
  end if;

  perform pg_advisory_xact_lock(
    ('x' || substr(md5('user_resource_reservation:' || p_user_resource_id::text), 1, 16))::bit(64)::bigint
  );

  select *
  into v_user_resource
  from public.user_resources ur
  where ur.id = p_user_resource_id
    and ur.resource_id = p_resource_id
    and ur.user_id = p_supplier_profile_id
  for update;

  if not found then
    raise exception 'Selected user_resource row not found for supplier/resource';
  end if;

  select coalesce(sum(rr.quantity), 0)::integer
  into v_own_reserved_quantity
  from public.resource_reservations rr
  where rr.user_resource_id = p_user_resource_id
    and rr.requester_profile_id = p_requester_profile_id
    and rr.status in ('pending', 'tentative');

  v_available_quantity := coalesce(v_user_resource.quantity, 0);

  v_grantable_quantity := least(
    p_quantity,
    greatest(v_available_quantity - v_own_reserved_quantity, 0)
  );

  if v_grantable_quantity <= 0 then
    raise exception 'No available inventory remains for this candidate row';
  end if;

  insert into public.requests (
    resource_id,
    quantity,
    notes,
    request_scope,
    requester_profile_id,
    supplier_profile_id,
    distance_meters,
    expires_at
  )
  values (
    p_resource_id,
    v_grantable_quantity,
    p_notes,
    p_request_scope,
    p_requester_profile_id,
    p_supplier_profile_id,
    p_distance_meters,
    p_expires_at
  )
  returning * into v_request;

  insert into public.resource_reservations (
    id,
    user_resource_id,
    request_id,
    requester_profile_id,
    quantity,
    status,
    created_at,
    updated_at,
    expires_at
  )
  values (
    extensions.gen_random_uuid(),
    p_user_resource_id,
    v_request.id,
    p_requester_profile_id,
    v_grantable_quantity,
    'pending',
    now(),
    now(),
    p_expires_at
  );

  return v_request;
end; -- 5$$;


ALTER FUNCTION "public"."reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text", "p_distance_meters" double precision) OWNER TO "supabase_admin";

--
-- Name: reserve_request_candidate_v3("uuid", integer, "public"."request_scope", "uuid", "uuid", "uuid", timestamp without time zone, integer, "text", double precision); Type: FUNCTION; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE FUNCTION "public"."reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text" DEFAULT NULL::"text", "p_distance_meters" double precision DEFAULT NULL::double precision) RETURNS "public"."requests"
    LANGUAGE "plpgsql"
    AS $$  -- 4
  declare
  v_request requests;
  v_user_resource user_resources;
  v_own_reserved_quantity integer;
  v_available_quantity integer;
  v_grantable_quantity integer;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'Quantity must be greater than 0';
  end if;

  perform pg_advisory_xact_lock(
    ('x' || substr(md5('user_resource_reservation:' || p_user_resource_id::text), 1, 16))::bit(64)::bigint
  );

  select *
  into v_user_resource
  from public.user_resources ur
  where ur.id = p_user_resource_id
    and ur.resource_id = p_resource_id
    and ur.user_id = p_supplier_profile_id
  for update;

  if not found then
    raise exception 'Selected user_resource row not found for supplier/resource';
  end if;

  select coalesce(sum(rr.quantity), 0)::integer
  into v_own_reserved_quantity
  from public.resource_reservations rr
  where rr.user_resource_id = p_user_resource_id
    and rr.requester_profile_id = p_requester_profile_id
    and rr.status in ('pending', 'tentative');

  v_available_quantity := coalesce(v_user_resource.quantity, 0);

  v_grantable_quantity := least(
    p_quantity,
    greatest(v_available_quantity - v_own_reserved_quantity, 0)
  );

  if v_grantable_quantity <= 0 then
    raise exception 'No available inventory remains for this candidate row';
  end if;

  insert into public.requests (
    resource_id,
    quantity,
    notes,
    request_scope,
    requester_profile_id,
    supplier_profile_id,
    distance_meters,
    expires_at,
    hours_needed
  )
  values (
    p_resource_id,
    v_grantable_quantity,
    p_notes,
    p_request_scope,
    p_requester_profile_id,
    p_supplier_profile_id,
    p_distance_meters,
    p_expires_at,
    p_hours_needed
  )
  returning * into v_request;

  insert into public.resource_reservations (
    id,
    user_resource_id,
    request_id,
    requester_profile_id,
    quantity,
    status,
    created_at,
    updated_at
  )
  values (
    extensions.gen_random_uuid(),
    p_user_resource_id,
    v_request.id,
    p_requester_profile_id,
    v_grantable_quantity,
    'pending',
    now(),
    now()
  );

  return v_request;
end; -- 5
$$;


ALTER FUNCTION "public"."reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text", "p_distance_meters" double precision) OWNER TO "supabase_admin";

--
-- Name: blocks; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE IF NOT EXISTS "public"."blocks" (
    "blocker" "uuid" NOT NULL,
    "blockee" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."blocks" OWNER TO "supabase_admin";

--
-- Name: checklist_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."checklist_steps" (
    "id" "uuid" NOT NULL,
    "label" character varying NOT NULL,
    "description" character varying,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "public"."checklist_steps" OWNER TO "postgres";

--
-- Name: checklist_steps_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."checklist_steps_orders" (
    "id" "uuid" NOT NULL,
    "checklist_id" "uuid" NOT NULL,
    "checklist_step_id" "uuid" NOT NULL,
    "priority" integer NOT NULL,
    "updated_at" timestamp without time zone NOT NULL
);


ALTER TABLE "public"."checklist_steps_orders" OWNER TO "postgres";

--
-- Name: checklist_steps_states; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."checklist_steps_states" (
    "id" "uuid" NOT NULL,
    "checklist_steps_order_id" "uuid" NOT NULL,
    "user_profile_id" "uuid" NOT NULL,
    "is_completed" boolean NOT NULL
);


ALTER TABLE "public"."checklist_steps_states" OWNER TO "postgres";

--
-- Name: checklists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."checklists" (
    "id" "uuid" NOT NULL,
    "title" character varying NOT NULL,
    "description" character varying,
    "notes" character varying,
    "updated_at" timestamp without time zone NOT NULL,
    "frequency_id" "uuid",
    "priority" "public"."priority" DEFAULT 'low'::"public"."priority" NOT NULL
);


ALTER TABLE "public"."checklists" OWNER TO "postgres";

--
-- Name: clusters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."clusters" (
    "id" "uuid" NOT NULL,
    "name" character varying,
    "meeting_place" character varying,
    "meeting_point" "extensions"."geometry"(Point),
    "notes" character varying,
    "geom" "extensions"."geometry"(Polygon)
);


ALTER TABLE "public"."clusters" OWNER TO "postgres";

--
-- Name: people; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."people" (
    "id" "uuid" NOT NULL,
    "user_profile_id" "uuid",
    "given_name" character varying,
    "family_name" character varying,
    "nickname" character varying,
    "is_safe" boolean NOT NULL,
    "needs_help" boolean NOT NULL
);


ALTER TABLE "public"."people" OWNER TO "postgres";

--
-- Name: user_captain_clusters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."user_captain_clusters" (
    "id" "uuid" NOT NULL,
    "cluster_id" "uuid" NOT NULL,
    "user_role_id" "uuid" NOT NULL
);


ALTER TABLE "public"."user_captain_clusters" OWNER TO "postgres";

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."user_roles" (
    "id" "uuid" NOT NULL,
    "user_profile_id" "uuid" NOT NULL,
    "role" "public"."app_roles" DEFAULT 'user'::"public"."app_roles" NOT NULL
);


ALTER TABLE "public"."user_roles" OWNER TO "postgres";

--
-- Name: cluster_captains_view; Type: VIEW; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE VIEW "public"."cluster_captains_view" AS
 WITH "crs" AS (
         SELECT "c"."id" AS "cluster_id",
            "c"."name" AS "cluster_name",
            "uc"."user_role_id"
           FROM ("public"."clusters" "c"
             JOIN "public"."user_captain_clusters" "uc" ON (("uc"."cluster_id" = "c"."id")))
        ), "urp" AS (
         SELECT "ur"."id",
            "ur"."user_profile_id",
            "ur"."role" AS "user_role",
            "p"."given_name",
            "p"."family_name",
            "p"."nickname"
           FROM ("public"."user_roles" "ur"
             JOIN "public"."people" "p" ON (("ur"."user_profile_id" = "p"."user_profile_id")))
        )
 SELECT "crs"."cluster_id",
    "crs"."cluster_name",
    "urp"."user_role",
    "urp"."user_profile_id",
    "urp"."given_name",
    "urp"."family_name",
    "urp"."nickname"
   FROM ("crs"
     JOIN "urp" ON (("urp"."id" = "crs"."user_role_id")));


ALTER TABLE "public"."cluster_captains_view" OWNER TO "supabase_admin";

--
-- Name: frequency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."frequency" (
    "id" "uuid" NOT NULL,
    "name" character varying NOT NULL,
    "num_days" integer NOT NULL
);


ALTER TABLE "public"."frequency" OWNER TO "postgres";

--
-- Name: group_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."group_members" (
    "group_id" "uuid" NOT NULL,
    "profile_id" "uuid" NOT NULL
);


ALTER TABLE "public"."group_members" OWNER TO "postgres";

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."groups" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_by_id" "uuid" NOT NULL,
    "name" character varying NOT NULL,
    "description" character varying,
    "type" "public"."group_chat_type" DEFAULT 'chat'::"public"."group_chat_type" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."groups" OWNER TO "postgres";

--
-- Name: households; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."households" (
    "id" "uuid" NOT NULL,
    "cluster_id" "uuid" NOT NULL,
    "name" character varying,
    "address" character varying,
    "notes" character varying,
    "pets" character varying,
    "accessibility_needs" character varying,
    "geom" "extensions"."geometry"(Point),
    CONSTRAINT "households_geom_srid_check" CHECK ((("geom" IS NULL) OR ("extensions"."st_srid"("geom") = 4326)))
);


ALTER TABLE "public"."households" OWNER TO "postgres";

--
-- Name: message_reads; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE IF NOT EXISTS "public"."message_reads" (
    "message_id" "uuid" NOT NULL,
    "profile_id" "uuid" NOT NULL,
    "read_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."message_reads" OWNER TO "supabase_admin";

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."messages" (
    "id" "uuid" NOT NULL,
    "from_id" "uuid",
    "to_id" "uuid",
    "urgency" "public"."messageurgency",
    "content" character varying NOT NULL,
    "sent_on" timestamp without time zone NOT NULL,
    "message_type" "public"."message_type" DEFAULT 'text'::"public"."message_type" NOT NULL,
    "metadata" "jsonb",
    "request_id" "uuid"
);


ALTER TABLE "public"."messages" OWNER TO "postgres";

--
-- Name: COLUMN "messages"."message_type"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."messages"."message_type" IS 'currently text or resource_request';


--
-- Name: COLUMN "messages"."metadata"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."messages"."metadata" IS 'if message is a request, carries request info in json';


--
-- Name: operational_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."operational_events" (
    "id" "uuid" NOT NULL,
    "created_by" "uuid" NOT NULL,
    "created_at" timestamp without time zone NOT NULL,
    "status" "public"."operational_status" NOT NULL
);


ALTER TABLE "public"."operational_events" OWNER TO "postgres";

--
-- Name: people_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."people_groups" (
    "people_id" "uuid" NOT NULL,
    "household_id" "uuid",
    "notes" "text"
);


ALTER TABLE "public"."people_groups" OWNER TO "postgres";

--
-- Name: point_of_interest_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."point_of_interest_types" (
    "name" character varying NOT NULL,
    "icon" character varying NOT NULL,
    "category" "public"."poi_category"
);


ALTER TABLE "public"."point_of_interest_types" OWNER TO "postgres";

--
-- Name: resource_reservations; Type: TABLE; Schema: public; Owner: supabase_admin
--

CREATE TABLE IF NOT EXISTS "public"."resource_reservations" (
    "id" "uuid" DEFAULT "extensions"."gen_random_uuid"() NOT NULL,
    "user_resource_id" "uuid" NOT NULL,
    "request_id" "uuid" NOT NULL,
    "quantity" integer NOT NULL,
    "status" "public"."reservation_status" DEFAULT 'pending'::"public"."reservation_status" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp without time zone,
    "requester_profile_id" "uuid" NOT NULL,
    CONSTRAINT "resource_reservations_quantity_positive" CHECK (("quantity" > 0))
);


ALTER TABLE "public"."resource_reservations" OWNER TO "supabase_admin";

--
-- Name: resource_subtype_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."resource_subtype_tags" (
    "id" "uuid" NOT NULL,
    "name" character varying NOT NULL
);


ALTER TABLE "public"."resource_subtype_tags" OWNER TO "postgres";

--
-- Name: resource_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."resource_tags" (
    "resource_id" "uuid" NOT NULL,
    "resource_subtype_tag_id" "uuid"
);


ALTER TABLE "public"."resource_tags" OWNER TO "postgres";

--
-- Name: resource_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."resource_types" (
    "id" "uuid" NOT NULL,
    "name" character varying NOT NULL,
    "description" character varying
);


ALTER TABLE "public"."resource_types" OWNER TO "postgres";

--
-- Name: resources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."resources" (
    "resource_cv_id" "uuid" NOT NULL,
    "resource_type_id" "uuid" NOT NULL,
    "notes" character varying,
    "qty_needed" integer NOT NULL,
    "qty_available" integer NOT NULL
);


ALTER TABLE "public"."resources" OWNER TO "postgres";

--
-- Name: resources_cv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."resources_cv" (
    "id" "uuid" NOT NULL,
    "name" character varying NOT NULL,
    "description" character varying,
    "unit" "public"."unit" DEFAULT 'Unknown'::"public"."unit" NOT NULL
);


ALTER TABLE "public"."resources_cv" OWNER TO "postgres";

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."role_permissions" (
    "id" "uuid" NOT NULL,
    "role" "public"."app_roles" DEFAULT 'user'::"public"."app_roles" NOT NULL,
    "permission" "public"."app_permissions" DEFAULT 'operational_event_read'::"public"."app_permissions" NOT NULL
);


ALTER TABLE "public"."role_permissions" OWNER TO "postgres";

--
-- Name: signup_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."signup_codes" (
    "code" character varying(7) NOT NULL,
    "household_id" "uuid" NOT NULL
);


ALTER TABLE "public"."signup_codes" OWNER TO "postgres";

--
-- Name: user_checklists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."user_checklists" (
    "id" "uuid" NOT NULL,
    "checklist_id" "uuid" NOT NULL,
    "user_profile_id" "uuid" NOT NULL,
    "completed_at" timestamp without time zone
);


ALTER TABLE "public"."user_checklists" OWNER TO "postgres";

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE IF NOT EXISTS "public"."user_profiles" (
    "id" "uuid" NOT NULL
);


ALTER TABLE "public"."user_profiles" OWNER TO "postgres";

--
-- Name: user_resources_view; Type: VIEW; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE VIEW "public"."user_resources_view" AS
 WITH "urs" AS (
         SELECT "ur"."id",
            "ur"."user_id",
            "ur"."quantity",
            "ur"."notes",
            "ur"."created_at",
            "ur"."updated_at",
            "r"."resource_cv_id" AS "rc_id",
            "r"."resource_type_id" AS "rt_id"
           FROM ("public"."user_resources" "ur"
             JOIN "public"."resources" "r" ON (("r"."resource_cv_id" = "ur"."resource_id")))
        )
 SELECT "urs"."id",
    "urs"."user_id",
    "urs"."quantity",
    "urs"."notes",
    "urs"."created_at",
    "urs"."updated_at",
    "rc"."id" AS "rc_id",
    "rc"."name" AS "rc_name",
    "rc"."description" AS "rc_desc",
    "rt"."id" AS "rt_id",
    "rt"."name" AS "rt_name",
    "rt"."description" AS "rt_desc"
   FROM "public"."resources_cv" "rc",
    "public"."resource_types" "rt",
    "urs"
  WHERE (("rc"."id" = "urs"."rc_id") AND ("rt"."id" = "urs"."rt_id"));


ALTER TABLE "public"."user_resources_view" OWNER TO "supabase_admin";

--
-- Name: blocks blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."blocks"
    ADD CONSTRAINT "blocks_pkey" PRIMARY KEY ("blocker", "blockee");


--
-- Name: checklist_steps_orders checklist_steps_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps_orders"
    ADD CONSTRAINT "checklist_steps_orders_pkey" PRIMARY KEY ("id");


--
-- Name: checklist_steps checklist_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps"
    ADD CONSTRAINT "checklist_steps_pkey" PRIMARY KEY ("id");


--
-- Name: checklist_steps_states checklist_steps_states_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps_states"
    ADD CONSTRAINT "checklist_steps_states_pkey" PRIMARY KEY ("id");


--
-- Name: checklists checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklists"
    ADD CONSTRAINT "checklists_pkey" PRIMARY KEY ("id");


--
-- Name: clusters clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."clusters"
    ADD CONSTRAINT "clusters_pkey" PRIMARY KEY ("id");


--
-- Name: frequency frequency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."frequency"
    ADD CONSTRAINT "frequency_pkey" PRIMARY KEY ("id");


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."group_members"
    ADD CONSTRAINT "group_members_pkey" PRIMARY KEY ("group_id", "profile_id");


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."groups"
    ADD CONSTRAINT "groups_pkey" PRIMARY KEY ("id");


--
-- Name: households households_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."households"
    ADD CONSTRAINT "households_pkey" PRIMARY KEY ("id");


--
-- Name: message_reads message_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."message_reads"
    ADD CONSTRAINT "message_reads_pkey" PRIMARY KEY ("message_id", "profile_id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id");


--
-- Name: operational_events operational_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."operational_events"
    ADD CONSTRAINT "operational_events_pkey" PRIMARY KEY ("id");


--
-- Name: people_groups people_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."people_groups"
    ADD CONSTRAINT "people_groups_pkey" PRIMARY KEY ("people_id");


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."people"
    ADD CONSTRAINT "people_pkey" PRIMARY KEY ("id");


--
-- Name: people people_user_profile_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."people"
    ADD CONSTRAINT "people_user_profile_id_key" UNIQUE ("user_profile_id");


--
-- Name: point_of_interest_types point_of_interest_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."point_of_interest_types"
    ADD CONSTRAINT "point_of_interest_types_pkey" PRIMARY KEY ("name");


--
-- Name: point_of_interests point_of_interests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."point_of_interests"
    ADD CONSTRAINT "point_of_interests_pkey" PRIMARY KEY ("id");


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."requests"
    ADD CONSTRAINT "requests_pkey" PRIMARY KEY ("id");


--
-- Name: resource_reservations resource_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."resource_reservations"
    ADD CONSTRAINT "resource_reservations_pkey" PRIMARY KEY ("id");


--
-- Name: resource_subtype_tags resource_subtype_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resource_subtype_tags"
    ADD CONSTRAINT "resource_subtype_tags_pkey" PRIMARY KEY ("id");


--
-- Name: resource_tags resource_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resource_tags"
    ADD CONSTRAINT "resource_tags_pkey" PRIMARY KEY ("resource_id");


--
-- Name: resource_types resource_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resource_types"
    ADD CONSTRAINT "resource_types_pkey" PRIMARY KEY ("id");


--
-- Name: resources_cv resources_cv_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resources_cv"
    ADD CONSTRAINT "resources_cv_pkey" PRIMARY KEY ("id");


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resources"
    ADD CONSTRAINT "resources_pkey" PRIMARY KEY ("resource_cv_id");


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."role_permissions"
    ADD CONSTRAINT "role_permissions_pkey" PRIMARY KEY ("id");


--
-- Name: signup_codes signup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."signup_codes"
    ADD CONSTRAINT "signup_codes_pkey" PRIMARY KEY ("code");


--
-- Name: user_captain_clusters user_captain_clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_captain_clusters"
    ADD CONSTRAINT "user_captain_clusters_pkey" PRIMARY KEY ("id");


--
-- Name: user_checklists user_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_checklists"
    ADD CONSTRAINT "user_checklists_pkey" PRIMARY KEY ("id");


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_pkey" PRIMARY KEY ("id");


--
-- Name: user_resources user_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_resources"
    ADD CONSTRAINT "user_resources_pkey" PRIMARY KEY ("id");


--
-- Name: user_resources user_resources_unique_supply; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_resources"
    ADD CONSTRAINT "user_resources_unique_supply" UNIQUE ("user_id", "resource_id", "sharing_scope", "sharing_scope_emergency");


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_roles"
    ADD CONSTRAINT "user_roles_pkey" PRIMARY KEY ("id");


--
-- Name: user_roles user_roles_user_profile_id_role_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_roles"
    ADD CONSTRAINT "user_roles_user_profile_id_role_key" UNIQUE ("user_profile_id", "role");


--
-- Name: idx_clusters_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_clusters_geom" ON "public"."clusters" USING "gist" ("geom");


--
-- Name: idx_clusters_meeting_point; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_clusters_meeting_point" ON "public"."clusters" USING "gist" ("meeting_point");


--
-- Name: idx_households_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_households_geom" ON "public"."households" USING "gist" ("geom");


--
-- Name: idx_point_of_interests_geom; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_point_of_interests_geom" ON "public"."point_of_interests" USING "gist" ("geom");


--
-- Name: resource_reservations on_reservation_status_change; Type: TRIGGER; Schema: public; Owner: supabase_admin
--

CREATE OR REPLACE TRIGGER "on_reservation_status_change" AFTER UPDATE ON "public"."resource_reservations" FOR EACH ROW EXECUTE FUNCTION "public"."handle_reservation_status_change"();


--
-- Name: checklist_steps trigger_delete_checklist_step_cascade; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE OR REPLACE TRIGGER "trigger_delete_checklist_step_cascade" BEFORE DELETE ON "public"."checklist_steps" FOR EACH ROW EXECUTE FUNCTION "public"."delete_checklist_step_cascade"();


--
-- Name: checklist_steps_orders trigger_insert_checklist_steps_state_for_all_users; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE OR REPLACE TRIGGER "trigger_insert_checklist_steps_state_for_all_users" AFTER INSERT ON "public"."checklist_steps_orders" FOR EACH ROW EXECUTE FUNCTION "public"."insert_checklist_steps_state_for_all_users"();


--
-- Name: checklists trigger_insert_user_checklists_for_all_users; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE OR REPLACE TRIGGER "trigger_insert_user_checklists_for_all_users" AFTER INSERT ON "public"."checklists" FOR EACH ROW EXECUTE FUNCTION "public"."insert_user_checklists_for_all_users"();


--
-- Name: checklist_steps_orders checklist_steps_orders_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps_orders"
    ADD CONSTRAINT "checklist_steps_orders_checklist_id_fkey" FOREIGN KEY ("checklist_id") REFERENCES "public"."checklists"("id");


--
-- Name: checklist_steps_orders checklist_steps_orders_checklist_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps_orders"
    ADD CONSTRAINT "checklist_steps_orders_checklist_step_id_fkey" FOREIGN KEY ("checklist_step_id") REFERENCES "public"."checklist_steps"("id");


--
-- Name: checklist_steps_states checklist_steps_states_checklist_steps_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps_states"
    ADD CONSTRAINT "checklist_steps_states_checklist_steps_order_id_fkey" FOREIGN KEY ("checklist_steps_order_id") REFERENCES "public"."checklist_steps_orders"("id");


--
-- Name: checklists checklists_frequency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklists"
    ADD CONSTRAINT "checklists_frequency_id_fkey" FOREIGN KEY ("frequency_id") REFERENCES "public"."frequency"("id");


--
-- Name: households households_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."households"
    ADD CONSTRAINT "households_cluster_id_fkey" FOREIGN KEY ("cluster_id") REFERENCES "public"."clusters"("id");


--
-- Name: people_groups people_groups_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."people_groups"
    ADD CONSTRAINT "people_groups_household_id_fkey" FOREIGN KEY ("household_id") REFERENCES "public"."households"("id");


--
-- Name: point_of_interests point_of_interests_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."point_of_interests"
    ADD CONSTRAINT "point_of_interests_cluster_id_fkey" FOREIGN KEY ("cluster_id") REFERENCES "public"."clusters"("id");


--
-- Name: point_of_interests point_of_interests_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."point_of_interests"
    ADD CONSTRAINT "point_of_interests_household_id_fkey" FOREIGN KEY ("household_id") REFERENCES "public"."households"("id");


--
-- Name: point_of_interests point_of_interests_point_type_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."point_of_interests"
    ADD CONSTRAINT "point_of_interests_point_type_name_fkey" FOREIGN KEY ("point_type_name") REFERENCES "public"."point_of_interest_types"("name");


--
-- Name: point_of_interests point_of_interests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."point_of_interests"
    ADD CONSTRAINT "point_of_interests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."user_profiles"("id");


--
-- Name: blocks public_blocks_blockee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."blocks"
    ADD CONSTRAINT "public_blocks_blockee_fkey" FOREIGN KEY ("blockee") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: blocks public_blocks_blocker_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."blocks"
    ADD CONSTRAINT "public_blocks_blocker_fkey" FOREIGN KEY ("blocker") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: checklist_steps_states public_checklist_steps_states_user_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."checklist_steps_states"
    ADD CONSTRAINT "public_checklist_steps_states_user_profile_id_fkey" FOREIGN KEY ("user_profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_members public_group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."group_members"
    ADD CONSTRAINT "public_group_members_group_id_fkey" FOREIGN KEY ("group_id") REFERENCES "public"."groups"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_members public_group_members_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."group_members"
    ADD CONSTRAINT "public_group_members_profile_id_fkey" FOREIGN KEY ("profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: groups public_groups_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."groups"
    ADD CONSTRAINT "public_groups_created_by_id_fkey" FOREIGN KEY ("created_by_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: message_reads public_message_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."message_reads"
    ADD CONSTRAINT "public_message_reads_message_id_fkey" FOREIGN KEY ("message_id") REFERENCES "public"."messages"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: message_reads public_message_reads_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."message_reads"
    ADD CONSTRAINT "public_message_reads_profile_id_fkey" FOREIGN KEY ("profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages public_messages_from_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "public_messages_from_id_fkey" FOREIGN KEY ("from_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages public_messages_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "public_messages_request_id_fkey" FOREIGN KEY ("request_id") REFERENCES "public"."requests"("id");


--
-- Name: messages public_messages_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "public_messages_to_id_fkey" FOREIGN KEY ("to_id") REFERENCES "public"."groups"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: operational_events public_operational_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."operational_events"
    ADD CONSTRAINT "public_operational_events_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: people_groups public_people_groups_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."people_groups"
    ADD CONSTRAINT "public_people_groups_people_id_fkey" FOREIGN KEY ("people_id") REFERENCES "public"."people"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: people public_people_user_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."people"
    ADD CONSTRAINT "public_people_user_profile_id_fkey" FOREIGN KEY ("user_profile_id") REFERENCES "public"."user_profiles"("id") ON DELETE CASCADE;


--
-- Name: requests public_requests_requester_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."requests"
    ADD CONSTRAINT "public_requests_requester_profile_id_fkey" FOREIGN KEY ("requester_profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: requests public_requests_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."requests"
    ADD CONSTRAINT "public_requests_resource_id_fkey" FOREIGN KEY ("resource_id") REFERENCES "public"."resources"("resource_cv_id");


--
-- Name: requests public_requests_supplier_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."requests"
    ADD CONSTRAINT "public_requests_supplier_profile_id_fkey" FOREIGN KEY ("supplier_profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resource_reservations public_resource_reservations_requester_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."resource_reservations"
    ADD CONSTRAINT "public_resource_reservations_requester_profile_id_fkey" FOREIGN KEY ("requester_profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resource_reservations public_resource_reservations_user_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."resource_reservations"
    ADD CONSTRAINT "public_resource_reservations_user_resource_id_fkey" FOREIGN KEY ("user_resource_id") REFERENCES "public"."user_resources"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_checklists public_user_checklists_user_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_checklists"
    ADD CONSTRAINT "public_user_checklists_user_profile_id_fkey" FOREIGN KEY ("user_profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_profiles public_user_profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "public_user_profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_resources public_user_resources_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_resources"
    ADD CONSTRAINT "public_user_resources_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles public_user_roles_user_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_roles"
    ADD CONSTRAINT "public_user_roles_user_profile_id_fkey" FOREIGN KEY ("user_profile_id") REFERENCES "public"."user_profiles"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resource_reservations resource_reservations_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: supabase_admin
--

ALTER TABLE ONLY "public"."resource_reservations"
    ADD CONSTRAINT "resource_reservations_request_id_fkey" FOREIGN KEY ("request_id") REFERENCES "public"."requests"("id") ON DELETE CASCADE;


--
-- Name: resource_tags resource_tags_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resource_tags"
    ADD CONSTRAINT "resource_tags_resource_id_fkey" FOREIGN KEY ("resource_id") REFERENCES "public"."resources"("resource_cv_id");


--
-- Name: resource_tags resource_tags_resource_subtype_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resource_tags"
    ADD CONSTRAINT "resource_tags_resource_subtype_tag_id_fkey" FOREIGN KEY ("resource_subtype_tag_id") REFERENCES "public"."resource_subtype_tags"("id");


--
-- Name: resources resources_resource_cv_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resources"
    ADD CONSTRAINT "resources_resource_cv_id_fkey" FOREIGN KEY ("resource_cv_id") REFERENCES "public"."resources_cv"("id");


--
-- Name: resources resources_resource_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."resources"
    ADD CONSTRAINT "resources_resource_type_id_fkey" FOREIGN KEY ("resource_type_id") REFERENCES "public"."resource_types"("id");


--
-- Name: signup_codes signup_codes_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."signup_codes"
    ADD CONSTRAINT "signup_codes_household_id_fkey" FOREIGN KEY ("household_id") REFERENCES "public"."households"("id");


--
-- Name: user_captain_clusters user_captain_clusters_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_captain_clusters"
    ADD CONSTRAINT "user_captain_clusters_cluster_id_fkey" FOREIGN KEY ("cluster_id") REFERENCES "public"."clusters"("id");


--
-- Name: user_captain_clusters user_captain_clusters_user_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_captain_clusters"
    ADD CONSTRAINT "user_captain_clusters_user_role_id_fkey" FOREIGN KEY ("user_role_id") REFERENCES "public"."user_roles"("id");


--
-- Name: user_checklists user_checklists_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_checklists"
    ADD CONSTRAINT "user_checklists_checklist_id_fkey" FOREIGN KEY ("checklist_id") REFERENCES "public"."checklists"("id");


--
-- Name: user_resources user_resources_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."user_resources"
    ADD CONSTRAINT "user_resources_resource_id_fkey" FOREIGN KEY ("resource_id") REFERENCES "public"."resources"("resource_cv_id");


--
-- Name: operational_events Allow authorized INSERT access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authorized INSERT access" ON "public"."operational_events" FOR INSERT WITH CHECK ("public"."authorize"('operational_event_create'::"public"."app_permissions"));


--
-- Name: operational_events Allow authorized SELECT access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authorized SELECT access" ON "public"."operational_events" FOR SELECT USING (( SELECT "public"."authorize"('operational_event_read'::"public"."app_permissions") AS "authorize"));


--
-- Name: operational_events Allow authorized UPDATE access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authorized UPDATE access" ON "public"."operational_events" FOR UPDATE USING (( SELECT "public"."authorize"('operational_event_create'::"public"."app_permissions") AS "authorize"));


--
-- Name: operational_events; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."operational_events" ENABLE ROW LEVEL SECURITY;

--
-- Name: logflare_pub; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "logflare_pub" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "logflare_pub" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

-- CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime messages; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."messages";


--
-- Name: supabase_realtime operational_events; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."operational_events";


--
-- Name: SCHEMA "net"; Type: ACL; Schema: -; Owner: postgres
--

-- GRANT USAGE ON SCHEMA "net" TO "supabase_functions_admin";
-- GRANT USAGE ON SCHEMA "net" TO "anon";
-- GRANT USAGE ON SCHEMA "net" TO "authenticated";
-- GRANT USAGE ON SCHEMA "net" TO "service_role";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";
GRANT USAGE ON SCHEMA "public" TO "supabase_auth_admin";


--
-- Name: FUNCTION "box2d_in"("cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box2d_in"("cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box2d_out"("extensions"."box2d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box2d_out"("extensions"."box2d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box2df_in"("cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box2df_in"("cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box2df_out"("extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box2df_out"("extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box3d_in"("cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box3d_in"("cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box3d_out"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box3d_out"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_analyze"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_analyze"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_in"("cstring", "oid", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_in"("cstring", "oid", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_out"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_out"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_recv"("internal", "oid", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_recv"("internal", "oid", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_send"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_send"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_typmod_in"("cstring"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_typmod_in"("cstring"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_typmod_out"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_typmod_out"(integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_analyze"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_analyze"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_in"("cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_in"("cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_out"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_out"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_recv"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_recv"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_send"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_send"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_typmod_in"("cstring"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_typmod_in"("cstring"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_typmod_out"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_typmod_out"(integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gidx_in"("cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gidx_in"("cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gidx_out"("extensions"."gidx"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gidx_out"("extensions"."gidx") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "spheroid_in"("cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."spheroid_in"("cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "spheroid_out"("extensions"."spheroid"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."spheroid_out"("extensions"."spheroid") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box3d"("extensions"."box2d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box3d"("extensions"."box2d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("extensions"."box2d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("extensions"."box2d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box2d"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box2d"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "bytea"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."bytea"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography"("extensions"."geography", integer, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography"("extensions"."geography", integer, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box2d"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box2d"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "box3d"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box3d"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "bytea"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."bytea"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("extensions"."geometry", integer, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("extensions"."geometry", integer, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "json"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."json"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "jsonb"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."jsonb"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "path"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."path"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "point"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."point"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "polygon"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."polygon"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "text"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."text"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("path"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("path") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("point"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("point") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("polygon"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("polygon") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_deprecate"("oldname" "text", "newname" "text", "version" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_deprecate"("oldname" "text", "newname" "text", "version" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_index_extent"("tbl" "regclass", "col" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_index_extent"("tbl" "regclass", "col" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_join_selectivity"("regclass", "text", "regclass", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_join_selectivity"("regclass", "text", "regclass", "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_pgsql_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_pgsql_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_scripts_pgsql_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_scripts_pgsql_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_selectivity"("tbl" "regclass", "att_name" "text", "geom" "extensions"."geometry", "mode" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_selectivity"("tbl" "regclass", "att_name" "text", "geom" "extensions"."geometry", "mode" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_postgis_stats"("tbl" "regclass", "att_name" "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_postgis_stats"("tbl" "regclass", "att_name" "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_3ddfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_3ddfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_3ddwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_3ddwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_3dintersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_3dintersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_asgml"(integer, "extensions"."geometry", integer, integer, "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_asgml"(integer, "extensions"."geometry", integer, integer, "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_asx3d"(integer, "extensions"."geometry", integer, integer, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_asx3d"(integer, "extensions"."geometry", integer, integer, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_bestsrid"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_bestsrid"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_bestsrid"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_bestsrid"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_concavehull"("param_inputgeom" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_concavehull"("param_inputgeom" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_contains"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_contains"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_containsproperly"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_containsproperly"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_coveredby"("geog1" "extensions"."geography", "geog2" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_coveredby"("geog1" "extensions"."geography", "geog2" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_coveredby"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_coveredby"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_covers"("geog1" "extensions"."geography", "geog2" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_covers"("geog1" "extensions"."geography", "geog2" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_covers"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_covers"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_crosses"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_crosses"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_dfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_dfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_distancetree"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_distancetree"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_distancetree"("extensions"."geography", "extensions"."geography", double precision, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_distancetree"("extensions"."geography", "extensions"."geography", double precision, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_distanceuncached"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_distanceuncached"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_distanceuncached"("extensions"."geography", "extensions"."geography", boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_distanceuncached"("extensions"."geography", "extensions"."geography", boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_distanceuncached"("extensions"."geography", "extensions"."geography", double precision, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_distanceuncached"("extensions"."geography", "extensions"."geography", double precision, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_dwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_dwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_dwithin"("geog1" "extensions"."geography", "geog2" "extensions"."geography", "tolerance" double precision, "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_dwithin"("geog1" "extensions"."geography", "geog2" "extensions"."geography", "tolerance" double precision, "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_dwithinuncached"("extensions"."geography", "extensions"."geography", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_dwithinuncached"("extensions"."geography", "extensions"."geography", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_dwithinuncached"("extensions"."geography", "extensions"."geography", double precision, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_dwithinuncached"("extensions"."geography", "extensions"."geography", double precision, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_equals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_equals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_expand"("extensions"."geography", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_expand"("extensions"."geography", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_geomfromgml"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_geomfromgml"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_intersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_intersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_linecrossingdirection"("line1" "extensions"."geometry", "line2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_linecrossingdirection"("line1" "extensions"."geometry", "line2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_longestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_longestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_maxdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_maxdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_orderingequals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_orderingequals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_overlaps"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_overlaps"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_pointoutside"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_pointoutside"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_sortablehash"("geom" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_sortablehash"("geom" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_touches"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_touches"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_voronoi"("g1" "extensions"."geometry", "clip" "extensions"."geometry", "tolerance" double precision, "return_polygons" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_voronoi"("g1" "extensions"."geometry", "clip" "extensions"."geometry", "tolerance" double precision, "return_polygons" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "_st_within"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."_st_within"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "addauth"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."addauth"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "addgeometrycolumn"("table_name" character varying, "column_name" character varying, "new_srid" integer, "new_type" character varying, "new_dim" integer, "use_typmod" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."addgeometrycolumn"("table_name" character varying, "column_name" character varying, "new_srid" integer, "new_type" character varying, "new_dim" integer, "use_typmod" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "addgeometrycolumn"("schema_name" character varying, "table_name" character varying, "column_name" character varying, "new_srid" integer, "new_type" character varying, "new_dim" integer, "use_typmod" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."addgeometrycolumn"("schema_name" character varying, "table_name" character varying, "column_name" character varying, "new_srid" integer, "new_type" character varying, "new_dim" integer, "use_typmod" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "addgeometrycolumn"("catalog_name" character varying, "schema_name" character varying, "table_name" character varying, "column_name" character varying, "new_srid_in" integer, "new_type" character varying, "new_dim" integer, "use_typmod" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."addgeometrycolumn"("catalog_name" character varying, "schema_name" character varying, "table_name" character varying, "column_name" character varying, "new_srid_in" integer, "new_type" character varying, "new_dim" integer, "use_typmod" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "algorithm_sign"("signables" "text", "secret" "text", "algorithm" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."algorithm_sign"("signables" "text", "secret" "text", "algorithm" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."algorithm_sign"("signables" "text", "secret" "text", "algorithm" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."algorithm_sign"("signables" "text", "secret" "text", "algorithm" "text") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "box3dtobox"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."box3dtobox"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "checkauth"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."checkauth"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "checkauth"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."checkauth"("text", "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "checkauthtrigger"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."checkauthtrigger"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "contains_2d"("extensions"."box2df", "extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."contains_2d"("extensions"."box2df", "extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "contains_2d"("extensions"."box2df", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."contains_2d"("extensions"."box2df", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "contains_2d"("extensions"."geometry", "extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."contains_2d"("extensions"."geometry", "extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "disablelongtransactions"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."disablelongtransactions"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "dropgeometrycolumn"("table_name" character varying, "column_name" character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."dropgeometrycolumn"("table_name" character varying, "column_name" character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "dropgeometrycolumn"("schema_name" character varying, "table_name" character varying, "column_name" character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."dropgeometrycolumn"("schema_name" character varying, "table_name" character varying, "column_name" character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "dropgeometrycolumn"("catalog_name" character varying, "schema_name" character varying, "table_name" character varying, "column_name" character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."dropgeometrycolumn"("catalog_name" character varying, "schema_name" character varying, "table_name" character varying, "column_name" character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "dropgeometrytable"("table_name" character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."dropgeometrytable"("table_name" character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "dropgeometrytable"("schema_name" character varying, "table_name" character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."dropgeometrytable"("schema_name" character varying, "table_name" character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "dropgeometrytable"("catalog_name" character varying, "schema_name" character varying, "table_name" character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."dropgeometrytable"("catalog_name" character varying, "schema_name" character varying, "table_name" character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "enablelongtransactions"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."enablelongtransactions"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "equals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."equals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "find_srid"(character varying, character varying, character varying); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."find_srid"(character varying, character varying, character varying) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "geog_brin_inclusion_add_value"("internal", "internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geog_brin_inclusion_add_value"("internal", "internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_cmp"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_cmp"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_distance_knn"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_distance_knn"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_eq"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_eq"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_ge"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_ge"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_compress"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_compress"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_consistent"("internal", "extensions"."geography", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_consistent"("internal", "extensions"."geography", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_decompress"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_decompress"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_distance"("internal", "extensions"."geography", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_distance"("internal", "extensions"."geography", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_penalty"("internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_penalty"("internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_picksplit"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_picksplit"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_same"("extensions"."box2d", "extensions"."box2d", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_same"("extensions"."box2d", "extensions"."box2d", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gist_union"("bytea", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gist_union"("bytea", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_gt"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_gt"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_le"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_le"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_lt"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_lt"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_overlaps"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_overlaps"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_spgist_choose_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_spgist_choose_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_spgist_compress_nd"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_spgist_compress_nd"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_spgist_config_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_spgist_config_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_spgist_inner_consistent_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_spgist_inner_consistent_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_spgist_leaf_consistent_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_spgist_leaf_consistent_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geography_spgist_picksplit_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geography_spgist_picksplit_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geom2d_brin_inclusion_add_value"("internal", "internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geom2d_brin_inclusion_add_value"("internal", "internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geom3d_brin_inclusion_add_value"("internal", "internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geom3d_brin_inclusion_add_value"("internal", "internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geom4d_brin_inclusion_add_value"("internal", "internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geom4d_brin_inclusion_add_value"("internal", "internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_above"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_above"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_below"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_below"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_cmp"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_cmp"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_contained_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_contained_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_contains"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_contains"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_contains_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_contains_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_contains_nd"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_contains_nd"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_distance_box"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_distance_box"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_distance_centroid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_distance_centroid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_distance_centroid_nd"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_distance_centroid_nd"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_distance_cpa"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_distance_cpa"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_eq"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_eq"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_ge"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_ge"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_compress_2d"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_compress_2d"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_compress_nd"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_compress_nd"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_consistent_2d"("internal", "extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_consistent_2d"("internal", "extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_consistent_nd"("internal", "extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_consistent_nd"("internal", "extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_decompress_2d"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_decompress_2d"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_decompress_nd"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_decompress_nd"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_distance_2d"("internal", "extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_distance_2d"("internal", "extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_distance_nd"("internal", "extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_distance_nd"("internal", "extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_penalty_2d"("internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_penalty_2d"("internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_penalty_nd"("internal", "internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_penalty_nd"("internal", "internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_picksplit_2d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_picksplit_2d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_picksplit_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_picksplit_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_same_2d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_same_2d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_same_nd"("extensions"."geometry", "extensions"."geometry", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_same_nd"("extensions"."geometry", "extensions"."geometry", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_sortsupport_2d"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_sortsupport_2d"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_union_2d"("bytea", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_union_2d"("bytea", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gist_union_nd"("bytea", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gist_union_nd"("bytea", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_gt"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_gt"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_hash"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_hash"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_le"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_le"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_left"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_left"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_lt"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_lt"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overabove"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overabove"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overbelow"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overbelow"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overlaps"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overlaps"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overlaps_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overlaps_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overlaps_nd"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overlaps_nd"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overleft"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overleft"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_overright"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_overright"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_right"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_right"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_same"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_same"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_same_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_same_3d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_same_nd"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_same_nd"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_sortsupport"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_sortsupport"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_choose_2d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_choose_2d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_choose_3d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_choose_3d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_choose_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_choose_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_compress_2d"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_compress_2d"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_compress_3d"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_compress_3d"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_compress_nd"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_compress_nd"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_config_2d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_config_2d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_config_3d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_config_3d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_config_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_config_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_inner_consistent_2d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_inner_consistent_2d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_inner_consistent_3d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_inner_consistent_3d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_inner_consistent_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_inner_consistent_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_leaf_consistent_2d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_leaf_consistent_2d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_leaf_consistent_3d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_leaf_consistent_3d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_leaf_consistent_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_leaf_consistent_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_picksplit_2d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_picksplit_2d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_picksplit_3d"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_picksplit_3d"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_spgist_picksplit_nd"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_spgist_picksplit_nd"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_within"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_within"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometry_within_nd"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometry_within_nd"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometrytype"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometrytype"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geometrytype"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geometrytype"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geomfromewkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geomfromewkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "geomfromewkt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."geomfromewkt"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_proj4_from_srid"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."get_proj4_from_srid"(integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gettransactionid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gettransactionid"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gserialized_gist_joinsel_2d"("internal", "oid", "internal", smallint); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gserialized_gist_joinsel_2d"("internal", "oid", "internal", smallint) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gserialized_gist_joinsel_nd"("internal", "oid", "internal", smallint); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gserialized_gist_joinsel_nd"("internal", "oid", "internal", smallint) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gserialized_gist_sel_2d"("internal", "oid", "internal", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gserialized_gist_sel_2d"("internal", "oid", "internal", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "gserialized_gist_sel_nd"("internal", "oid", "internal", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."gserialized_gist_sel_nd"("internal", "oid", "internal", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "is_contained_2d"("extensions"."box2df", "extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."is_contained_2d"("extensions"."box2df", "extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "is_contained_2d"("extensions"."box2df", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."is_contained_2d"("extensions"."box2df", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "is_contained_2d"("extensions"."geometry", "extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."is_contained_2d"("extensions"."geometry", "extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "lockrow"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."lockrow"("text", "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "lockrow"("text", "text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."lockrow"("text", "text", "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "lockrow"("text", "text", "text", timestamp without time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."lockrow"("text", "text", "text", timestamp without time zone) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "lockrow"("text", "text", "text", "text", timestamp without time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."lockrow"("text", "text", "text", "text", timestamp without time zone) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "longtransactionsenabled"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."longtransactionsenabled"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_2d"("extensions"."box2df", "extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_2d"("extensions"."box2df", "extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_2d"("extensions"."box2df", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_2d"("extensions"."box2df", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_2d"("extensions"."geometry", "extensions"."box2df"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_2d"("extensions"."geometry", "extensions"."box2df") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_geog"("extensions"."geography", "extensions"."gidx"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_geog"("extensions"."geography", "extensions"."gidx") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_geog"("extensions"."gidx", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_geog"("extensions"."gidx", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_geog"("extensions"."gidx", "extensions"."gidx"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_geog"("extensions"."gidx", "extensions"."gidx") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_nd"("extensions"."geometry", "extensions"."gidx"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_nd"("extensions"."geometry", "extensions"."gidx") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_nd"("extensions"."gidx", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_nd"("extensions"."gidx", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "overlaps_nd"("extensions"."gidx", "extensions"."gidx"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."overlaps_nd"("extensions"."gidx", "extensions"."gidx") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "blk_read_time" double precision, OUT "blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "blk_read_time" double precision, OUT "blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asflatgeobuf_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asflatgeobuf_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asflatgeobuf_transfn"("internal", "anyelement"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asflatgeobuf_transfn"("internal", "anyelement") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asflatgeobuf_transfn"("internal", "anyelement", boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asflatgeobuf_transfn"("internal", "anyelement", boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asflatgeobuf_transfn"("internal", "anyelement", boolean, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asflatgeobuf_transfn"("internal", "anyelement", boolean, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asgeobuf_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asgeobuf_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asgeobuf_transfn"("internal", "anyelement"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asgeobuf_transfn"("internal", "anyelement") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asgeobuf_transfn"("internal", "anyelement", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asgeobuf_transfn"("internal", "anyelement", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_combinefn"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_combinefn"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_deserialfn"("bytea", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_deserialfn"("bytea", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_serialfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_serialfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_transfn"("internal", "anyelement"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_transfn"("internal", "anyelement") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_transfn"("internal", "anyelement", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_transfn"("internal", "anyelement", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_transfn"("internal", "anyelement", "text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_transfn"("internal", "anyelement", "text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_transfn"("internal", "anyelement", "text", integer, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_transfn"("internal", "anyelement", "text", integer, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_asmvt_transfn"("internal", "anyelement", "text", integer, "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_asmvt_transfn"("internal", "anyelement", "text", integer, "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_accum_transfn"("internal", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_accum_transfn"("internal", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_accum_transfn"("internal", "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_accum_transfn"("internal", "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_accum_transfn"("internal", "extensions"."geometry", double precision, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_accum_transfn"("internal", "extensions"."geometry", double precision, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_clusterintersecting_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_clusterintersecting_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_clusterwithin_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_clusterwithin_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_collect_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_collect_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_makeline_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_makeline_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_polygonize_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_polygonize_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_union_parallel_combinefn"("internal", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_union_parallel_combinefn"("internal", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_union_parallel_deserialfn"("bytea", "internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_union_parallel_deserialfn"("bytea", "internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_union_parallel_finalfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_union_parallel_finalfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_union_parallel_serialfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_union_parallel_serialfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_union_parallel_transfn"("internal", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_union_parallel_transfn"("internal", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgis_geometry_union_parallel_transfn"("internal", "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."pgis_geometry_union_parallel_transfn"("internal", "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "populate_geometry_columns"("use_typmod" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."populate_geometry_columns"("use_typmod" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "populate_geometry_columns"("tbl_oid" "oid", "use_typmod" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."populate_geometry_columns"("tbl_oid" "oid", "use_typmod" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_addbbox"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_addbbox"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_cache_bbox"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_cache_bbox"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_constraint_dims"("geomschema" "text", "geomtable" "text", "geomcolumn" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_constraint_dims"("geomschema" "text", "geomtable" "text", "geomcolumn" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_constraint_srid"("geomschema" "text", "geomtable" "text", "geomcolumn" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_constraint_srid"("geomschema" "text", "geomtable" "text", "geomcolumn" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_constraint_type"("geomschema" "text", "geomtable" "text", "geomcolumn" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_constraint_type"("geomschema" "text", "geomtable" "text", "geomcolumn" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_dropbbox"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_dropbbox"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_extensions_upgrade"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_extensions_upgrade"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_full_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_full_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_geos_noop"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_geos_noop"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_geos_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_geos_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_getbbox"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_getbbox"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_hasbbox"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_hasbbox"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_index_supportfn"("internal"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_index_supportfn"("internal") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_lib_build_date"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_lib_build_date"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_lib_revision"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_lib_revision"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_lib_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_lib_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_libjson_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_libjson_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_liblwgeom_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_liblwgeom_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_libprotobuf_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_libprotobuf_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_libxml_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_libxml_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_noop"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_noop"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_proj_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_proj_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_scripts_build_date"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_scripts_build_date"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_scripts_installed"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_scripts_installed"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_scripts_released"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_scripts_released"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_svn_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_svn_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_transform_geometry"("geom" "extensions"."geometry", "text", "text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_transform_geometry"("geom" "extensions"."geometry", "text", "text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_type_name"("geomname" character varying, "coord_dimension" integer, "use_new_name" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_type_name"("geomname" character varying, "coord_dimension" integer, "use_new_name" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_typmod_dims"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_typmod_dims"(integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_typmod_srid"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_typmod_srid"(integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_typmod_type"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_typmod_type"(integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "postgis_wagyu_version"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."postgis_wagyu_version"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "sign"("payload" "json", "secret" "text", "algorithm" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."sign"("payload" "json", "secret" "text", "algorithm" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."sign"("payload" "json", "secret" "text", "algorithm" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."sign"("payload" "json", "secret" "text", "algorithm" "text") TO "dashboard_user";


--
-- Name: FUNCTION "st_3dclosestpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dclosestpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3ddfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3ddfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3ddistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3ddistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3ddwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3ddwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dintersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dintersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dlength"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dlength"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dlineinterpolatepoint"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dlineinterpolatepoint"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dlongestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dlongestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dmakebox"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dmakebox"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dmaxdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dmaxdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dperimeter"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dperimeter"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_3dshortestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dshortestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_addmeasure"("extensions"."geometry", double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_addmeasure"("extensions"."geometry", double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_addpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_addpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_addpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_addpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_affine"("extensions"."geometry", double precision, double precision, double precision, double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_affine"("extensions"."geometry", double precision, double precision, double precision, double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_affine"("extensions"."geometry", double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_affine"("extensions"."geometry", double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_angle"("line1" "extensions"."geometry", "line2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_angle"("line1" "extensions"."geometry", "line2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_angle"("pt1" "extensions"."geometry", "pt2" "extensions"."geometry", "pt3" "extensions"."geometry", "pt4" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_angle"("pt1" "extensions"."geometry", "pt2" "extensions"."geometry", "pt3" "extensions"."geometry", "pt4" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_area"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_area"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_area"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_area"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_area"("geog" "extensions"."geography", "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_area"("geog" "extensions"."geography", "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_area2d"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_area2d"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asbinary"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asbinary"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asbinary"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asbinary"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asbinary"("extensions"."geography", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asbinary"("extensions"."geography", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asbinary"("extensions"."geometry", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asbinary"("extensions"."geometry", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asencodedpolyline"("geom" "extensions"."geometry", "nprecision" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asencodedpolyline"("geom" "extensions"."geometry", "nprecision" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkb"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkb"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkb"("extensions"."geometry", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkb"("extensions"."geometry", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkt"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkt"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkt"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkt"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkt"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkt"("extensions"."geography", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkt"("extensions"."geography", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asewkt"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asewkt"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgeojson"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgeojson"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgeojson"("geog" "extensions"."geography", "maxdecimaldigits" integer, "options" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgeojson"("geog" "extensions"."geography", "maxdecimaldigits" integer, "options" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgeojson"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgeojson"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgeojson"("r" "record", "geom_column" "text", "maxdecimaldigits" integer, "pretty_bool" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgeojson"("r" "record", "geom_column" "text", "maxdecimaldigits" integer, "pretty_bool" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgml"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgml"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgml"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgml"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgml"("geog" "extensions"."geography", "maxdecimaldigits" integer, "options" integer, "nprefix" "text", "id" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgml"("geog" "extensions"."geography", "maxdecimaldigits" integer, "options" integer, "nprefix" "text", "id" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgml"("version" integer, "geog" "extensions"."geography", "maxdecimaldigits" integer, "options" integer, "nprefix" "text", "id" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgml"("version" integer, "geog" "extensions"."geography", "maxdecimaldigits" integer, "options" integer, "nprefix" "text", "id" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgml"("version" integer, "geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer, "nprefix" "text", "id" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgml"("version" integer, "geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer, "nprefix" "text", "id" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ashexewkb"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ashexewkb"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ashexewkb"("extensions"."geometry", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ashexewkb"("extensions"."geometry", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_askml"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_askml"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_askml"("geog" "extensions"."geography", "maxdecimaldigits" integer, "nprefix" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_askml"("geog" "extensions"."geography", "maxdecimaldigits" integer, "nprefix" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_askml"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "nprefix" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_askml"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "nprefix" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_aslatlontext"("geom" "extensions"."geometry", "tmpl" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_aslatlontext"("geom" "extensions"."geometry", "tmpl" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmarc21"("geom" "extensions"."geometry", "format" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmarc21"("geom" "extensions"."geometry", "format" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmvtgeom"("geom" "extensions"."geometry", "bounds" "extensions"."box2d", "extent" integer, "buffer" integer, "clip_geom" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmvtgeom"("geom" "extensions"."geometry", "bounds" "extensions"."box2d", "extent" integer, "buffer" integer, "clip_geom" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_assvg"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_assvg"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_assvg"("geog" "extensions"."geography", "rel" integer, "maxdecimaldigits" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_assvg"("geog" "extensions"."geography", "rel" integer, "maxdecimaldigits" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_assvg"("geom" "extensions"."geometry", "rel" integer, "maxdecimaldigits" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_assvg"("geom" "extensions"."geometry", "rel" integer, "maxdecimaldigits" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astext"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astext"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astext"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astext"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astext"("extensions"."geography", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astext"("extensions"."geography", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astext"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astext"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astwkb"("geom" "extensions"."geometry", "prec" integer, "prec_z" integer, "prec_m" integer, "with_sizes" boolean, "with_boxes" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astwkb"("geom" "extensions"."geometry", "prec" integer, "prec_z" integer, "prec_m" integer, "with_sizes" boolean, "with_boxes" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_astwkb"("geom" "extensions"."geometry"[], "ids" bigint[], "prec" integer, "prec_z" integer, "prec_m" integer, "with_sizes" boolean, "with_boxes" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_astwkb"("geom" "extensions"."geometry"[], "ids" bigint[], "prec" integer, "prec_z" integer, "prec_m" integer, "with_sizes" boolean, "with_boxes" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asx3d"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asx3d"("geom" "extensions"."geometry", "maxdecimaldigits" integer, "options" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_azimuth"("geog1" "extensions"."geography", "geog2" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_azimuth"("geog1" "extensions"."geography", "geog2" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_azimuth"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_azimuth"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_bdmpolyfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_bdmpolyfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_bdpolyfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_bdpolyfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_boundary"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_boundary"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_boundingdiagonal"("geom" "extensions"."geometry", "fits" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_boundingdiagonal"("geom" "extensions"."geometry", "fits" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_box2dfromgeohash"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_box2dfromgeohash"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("extensions"."geography", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("extensions"."geography", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("text", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("text", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("extensions"."geography", double precision, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("extensions"."geography", double precision, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("extensions"."geography", double precision, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("extensions"."geography", double precision, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("geom" "extensions"."geometry", "radius" double precision, "quadsegs" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("geom" "extensions"."geometry", "radius" double precision, "quadsegs" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("geom" "extensions"."geometry", "radius" double precision, "options" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("geom" "extensions"."geometry", "radius" double precision, "options" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("text", double precision, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("text", double precision, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buffer"("text", double precision, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buffer"("text", double precision, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_buildarea"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_buildarea"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_centroid"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_centroid"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_centroid"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_centroid"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_centroid"("extensions"."geography", "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_centroid"("extensions"."geography", "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_chaikinsmoothing"("extensions"."geometry", integer, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_chaikinsmoothing"("extensions"."geometry", integer, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_cleangeometry"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_cleangeometry"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clipbybox2d"("geom" "extensions"."geometry", "box" "extensions"."box2d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clipbybox2d"("geom" "extensions"."geometry", "box" "extensions"."box2d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_closestpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_closestpoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_closestpointofapproach"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_closestpointofapproach"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clusterdbscan"("extensions"."geometry", "eps" double precision, "minpoints" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clusterdbscan"("extensions"."geometry", "eps" double precision, "minpoints" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clusterintersecting"("extensions"."geometry"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clusterintersecting"("extensions"."geometry"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clusterkmeans"("geom" "extensions"."geometry", "k" integer, "max_radius" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clusterkmeans"("geom" "extensions"."geometry", "k" integer, "max_radius" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clusterwithin"("extensions"."geometry"[], double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clusterwithin"("extensions"."geometry"[], double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_collect"("extensions"."geometry"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_collect"("extensions"."geometry"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_collect"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_collect"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_collectionextract"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_collectionextract"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_collectionextract"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_collectionextract"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_collectionhomogenize"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_collectionhomogenize"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_combinebbox"("extensions"."box2d", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_combinebbox"("extensions"."box2d", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_combinebbox"("extensions"."box3d", "extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_combinebbox"("extensions"."box3d", "extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_combinebbox"("extensions"."box3d", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_combinebbox"("extensions"."box3d", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_concavehull"("param_geom" "extensions"."geometry", "param_pctconvex" double precision, "param_allow_holes" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_concavehull"("param_geom" "extensions"."geometry", "param_pctconvex" double precision, "param_allow_holes" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_contains"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_contains"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_containsproperly"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_containsproperly"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_convexhull"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_convexhull"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_coorddim"("geometry" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_coorddim"("geometry" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_coveredby"("geog1" "extensions"."geography", "geog2" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_coveredby"("geog1" "extensions"."geography", "geog2" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_coveredby"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_coveredby"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_coveredby"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_coveredby"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_covers"("geog1" "extensions"."geography", "geog2" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_covers"("geog1" "extensions"."geography", "geog2" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_covers"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_covers"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_covers"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_covers"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_cpawithin"("extensions"."geometry", "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_cpawithin"("extensions"."geometry", "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_crosses"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_crosses"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_curvetoline"("geom" "extensions"."geometry", "tol" double precision, "toltype" integer, "flags" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_curvetoline"("geom" "extensions"."geometry", "tol" double precision, "toltype" integer, "flags" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_delaunaytriangles"("g1" "extensions"."geometry", "tolerance" double precision, "flags" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_delaunaytriangles"("g1" "extensions"."geometry", "tolerance" double precision, "flags" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dfullywithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_difference"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_difference"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dimension"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dimension"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_disjoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_disjoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distance"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distance"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distance"("geog1" "extensions"."geography", "geog2" "extensions"."geography", "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distance"("geog1" "extensions"."geography", "geog2" "extensions"."geography", "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distancecpa"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distancecpa"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distancesphere"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distancesphere"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distancesphere"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "radius" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distancesphere"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "radius" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distancespheroid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distancespheroid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_distancespheroid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "extensions"."spheroid"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_distancespheroid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "extensions"."spheroid") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dump"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dump"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dumppoints"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dumppoints"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dumprings"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dumprings"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dumpsegments"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dumpsegments"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dwithin"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dwithin"("text", "text", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dwithin"("text", "text", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_dwithin"("geog1" "extensions"."geography", "geog2" "extensions"."geography", "tolerance" double precision, "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_dwithin"("geog1" "extensions"."geography", "geog2" "extensions"."geography", "tolerance" double precision, "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_endpoint"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_endpoint"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_envelope"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_envelope"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_equals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_equals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_estimatedextent"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_estimatedextent"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_estimatedextent"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_estimatedextent"("text", "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_estimatedextent"("text", "text", "text", boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_estimatedextent"("text", "text", "text", boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_expand"("extensions"."box2d", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_expand"("extensions"."box2d", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_expand"("extensions"."box3d", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_expand"("extensions"."box3d", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_expand"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_expand"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_expand"("box" "extensions"."box2d", "dx" double precision, "dy" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_expand"("box" "extensions"."box2d", "dx" double precision, "dy" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_expand"("box" "extensions"."box3d", "dx" double precision, "dy" double precision, "dz" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_expand"("box" "extensions"."box3d", "dx" double precision, "dy" double precision, "dz" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_expand"("geom" "extensions"."geometry", "dx" double precision, "dy" double precision, "dz" double precision, "dm" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_expand"("geom" "extensions"."geometry", "dx" double precision, "dy" double precision, "dz" double precision, "dm" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_exteriorring"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_exteriorring"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_filterbym"("extensions"."geometry", double precision, double precision, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_filterbym"("extensions"."geometry", double precision, double precision, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_findextent"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_findextent"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_findextent"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_findextent"("text", "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_flipcoordinates"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_flipcoordinates"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_force2d"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_force2d"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_force3d"("geom" "extensions"."geometry", "zvalue" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_force3d"("geom" "extensions"."geometry", "zvalue" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_force3dm"("geom" "extensions"."geometry", "mvalue" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_force3dm"("geom" "extensions"."geometry", "mvalue" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_force3dz"("geom" "extensions"."geometry", "zvalue" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_force3dz"("geom" "extensions"."geometry", "zvalue" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_force4d"("geom" "extensions"."geometry", "zvalue" double precision, "mvalue" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_force4d"("geom" "extensions"."geometry", "zvalue" double precision, "mvalue" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcecollection"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcecollection"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcecurve"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcecurve"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcepolygonccw"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcepolygonccw"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcepolygoncw"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcepolygoncw"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcerhr"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcerhr"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcesfs"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcesfs"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_forcesfs"("extensions"."geometry", "version" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_forcesfs"("extensions"."geometry", "version" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_frechetdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_frechetdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_fromflatgeobuf"("anyelement", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_fromflatgeobuf"("anyelement", "bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_fromflatgeobuftotable"("text", "text", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_fromflatgeobuftotable"("text", "text", "bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_generatepoints"("area" "extensions"."geometry", "npoints" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_generatepoints"("area" "extensions"."geometry", "npoints" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_generatepoints"("area" "extensions"."geometry", "npoints" integer, "seed" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_generatepoints"("area" "extensions"."geometry", "npoints" integer, "seed" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geogfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geogfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geogfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geogfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geographyfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geographyfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geohash"("geog" "extensions"."geography", "maxchars" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geohash"("geog" "extensions"."geography", "maxchars" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geohash"("geom" "extensions"."geometry", "maxchars" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geohash"("geom" "extensions"."geometry", "maxchars" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomcollfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomcollfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomcollfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomcollfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomcollfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomcollfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomcollfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomcollfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geometricmedian"("g" "extensions"."geometry", "tolerance" double precision, "max_iter" integer, "fail_if_not_converged" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geometricmedian"("g" "extensions"."geometry", "tolerance" double precision, "max_iter" integer, "fail_if_not_converged" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geometryfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geometryfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geometryfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geometryfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geometryn"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geometryn"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geometrytype"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geometrytype"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromewkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromewkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromewkt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromewkt"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromgeohash"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromgeohash"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromgeojson"("json"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromgeojson"("json") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromgeojson"("jsonb"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromgeojson"("jsonb") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromgeojson"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromgeojson"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromgml"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromgml"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromgml"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromgml"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromkml"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromkml"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfrommarc21"("marc21xml" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfrommarc21"("marc21xml" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromtwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromtwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_geomfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_geomfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_gmltosql"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_gmltosql"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_gmltosql"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_gmltosql"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_hasarc"("geometry" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_hasarc"("geometry" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_hausdorffdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_hausdorffdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_hausdorffdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_hausdorffdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_hexagon"("size" double precision, "cell_i" integer, "cell_j" integer, "origin" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_hexagon"("size" double precision, "cell_i" integer, "cell_j" integer, "origin" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_hexagongrid"("size" double precision, "bounds" "extensions"."geometry", OUT "geom" "extensions"."geometry", OUT "i" integer, OUT "j" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_hexagongrid"("size" double precision, "bounds" "extensions"."geometry", OUT "geom" "extensions"."geometry", OUT "i" integer, OUT "j" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_interiorringn"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_interiorringn"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_interpolatepoint"("line" "extensions"."geometry", "point" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_interpolatepoint"("line" "extensions"."geometry", "point" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_intersection"("extensions"."geography", "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_intersection"("extensions"."geography", "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_intersection"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_intersection"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_intersection"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_intersection"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_intersects"("geog1" "extensions"."geography", "geog2" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_intersects"("geog1" "extensions"."geography", "geog2" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_intersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_intersects"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_intersects"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_intersects"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isclosed"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isclosed"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_iscollection"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_iscollection"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isempty"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isempty"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ispolygonccw"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ispolygonccw"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ispolygoncw"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ispolygoncw"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isring"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isring"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_issimple"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_issimple"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isvalid"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isvalid"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isvalid"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isvalid"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isvaliddetail"("geom" "extensions"."geometry", "flags" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isvaliddetail"("geom" "extensions"."geometry", "flags" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isvalidreason"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isvalidreason"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isvalidreason"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isvalidreason"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_isvalidtrajectory"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_isvalidtrajectory"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_length"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_length"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_length"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_length"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_length"("geog" "extensions"."geography", "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_length"("geog" "extensions"."geography", "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_length2d"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_length2d"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_length2dspheroid"("extensions"."geometry", "extensions"."spheroid"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_length2dspheroid"("extensions"."geometry", "extensions"."spheroid") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_lengthspheroid"("extensions"."geometry", "extensions"."spheroid"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_lengthspheroid"("extensions"."geometry", "extensions"."spheroid") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_letters"("letters" "text", "font" "json"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_letters"("letters" "text", "font" "json") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linecrossingdirection"("line1" "extensions"."geometry", "line2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linecrossingdirection"("line1" "extensions"."geometry", "line2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linefromencodedpolyline"("txtin" "text", "nprecision" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linefromencodedpolyline"("txtin" "text", "nprecision" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linefrommultipoint"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linefrommultipoint"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linefromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linefromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linefromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linefromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linefromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linefromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linefromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linefromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_lineinterpolatepoint"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_lineinterpolatepoint"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_lineinterpolatepoints"("extensions"."geometry", double precision, "repeat" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_lineinterpolatepoints"("extensions"."geometry", double precision, "repeat" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linelocatepoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linelocatepoint"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linemerge"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linemerge"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linemerge"("extensions"."geometry", boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linemerge"("extensions"."geometry", boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linestringfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linestringfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linestringfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linestringfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linesubstring"("extensions"."geometry", double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linesubstring"("extensions"."geometry", double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_linetocurve"("geometry" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_linetocurve"("geometry" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_locatealong"("geometry" "extensions"."geometry", "measure" double precision, "leftrightoffset" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_locatealong"("geometry" "extensions"."geometry", "measure" double precision, "leftrightoffset" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_locatebetween"("geometry" "extensions"."geometry", "frommeasure" double precision, "tomeasure" double precision, "leftrightoffset" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_locatebetween"("geometry" "extensions"."geometry", "frommeasure" double precision, "tomeasure" double precision, "leftrightoffset" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_locatebetweenelevations"("geometry" "extensions"."geometry", "fromelevation" double precision, "toelevation" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_locatebetweenelevations"("geometry" "extensions"."geometry", "fromelevation" double precision, "toelevation" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_longestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_longestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_m"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_m"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makebox2d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makebox2d"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makeenvelope"(double precision, double precision, double precision, double precision, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makeenvelope"(double precision, double precision, double precision, double precision, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makeline"("extensions"."geometry"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makeline"("extensions"."geometry"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makeline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makeline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makepoint"(double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makepoint"(double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makepoint"(double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makepoint"(double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makepoint"(double precision, double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makepoint"(double precision, double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makepointm"(double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makepointm"(double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makepolygon"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makepolygon"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makepolygon"("extensions"."geometry", "extensions"."geometry"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makepolygon"("extensions"."geometry", "extensions"."geometry"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makevalid"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makevalid"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makevalid"("geom" "extensions"."geometry", "params" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makevalid"("geom" "extensions"."geometry", "params" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_maxdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_maxdistance"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_maximuminscribedcircle"("extensions"."geometry", OUT "center" "extensions"."geometry", OUT "nearest" "extensions"."geometry", OUT "radius" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_maximuminscribedcircle"("extensions"."geometry", OUT "center" "extensions"."geometry", OUT "nearest" "extensions"."geometry", OUT "radius" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_memsize"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_memsize"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_minimumboundingcircle"("inputgeom" "extensions"."geometry", "segs_per_quarter" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_minimumboundingcircle"("inputgeom" "extensions"."geometry", "segs_per_quarter" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_minimumboundingradius"("extensions"."geometry", OUT "center" "extensions"."geometry", OUT "radius" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_minimumboundingradius"("extensions"."geometry", OUT "center" "extensions"."geometry", OUT "radius" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_minimumclearance"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_minimumclearance"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_minimumclearanceline"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_minimumclearanceline"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mlinefromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mlinefromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mlinefromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mlinefromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mlinefromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mlinefromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mlinefromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mlinefromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpointfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpointfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpointfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpointfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpointfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpointfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpointfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpointfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpolyfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpolyfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpolyfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpolyfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpolyfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpolyfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_mpolyfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_mpolyfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multi"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multi"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multilinefromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multilinefromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multilinestringfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multilinestringfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multilinestringfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multilinestringfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipointfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipointfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipointfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipointfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipointfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipointfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipolyfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipolyfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipolyfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipolyfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipolygonfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipolygonfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_multipolygonfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_multipolygonfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ndims"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ndims"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_node"("g" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_node"("g" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_normalize"("geom" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_normalize"("geom" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_npoints"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_npoints"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_nrings"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_nrings"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_numgeometries"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_numgeometries"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_numinteriorring"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_numinteriorring"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_numinteriorrings"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_numinteriorrings"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_numpatches"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_numpatches"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_numpoints"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_numpoints"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_offsetcurve"("line" "extensions"."geometry", "distance" double precision, "params" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_offsetcurve"("line" "extensions"."geometry", "distance" double precision, "params" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_orderingequals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_orderingequals"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_orientedenvelope"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_orientedenvelope"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_overlaps"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_overlaps"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_patchn"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_patchn"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_perimeter"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_perimeter"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_perimeter"("geog" "extensions"."geography", "use_spheroid" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_perimeter"("geog" "extensions"."geography", "use_spheroid" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_perimeter2d"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_perimeter2d"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_point"(double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_point"(double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_point"(double precision, double precision, "srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_point"(double precision, double precision, "srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointfromgeohash"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointfromgeohash"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointinsidecircle"("extensions"."geometry", double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointinsidecircle"("extensions"."geometry", double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointm"("xcoordinate" double precision, "ycoordinate" double precision, "mcoordinate" double precision, "srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointm"("xcoordinate" double precision, "ycoordinate" double precision, "mcoordinate" double precision, "srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointn"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointn"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointonsurface"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointonsurface"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_points"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_points"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointz"("xcoordinate" double precision, "ycoordinate" double precision, "zcoordinate" double precision, "srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointz"("xcoordinate" double precision, "ycoordinate" double precision, "zcoordinate" double precision, "srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_pointzm"("xcoordinate" double precision, "ycoordinate" double precision, "zcoordinate" double precision, "mcoordinate" double precision, "srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_pointzm"("xcoordinate" double precision, "ycoordinate" double precision, "zcoordinate" double precision, "mcoordinate" double precision, "srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polyfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polyfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polyfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polyfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polyfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polyfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polyfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polyfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygon"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygon"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygonfromtext"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygonfromtext"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygonfromtext"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygonfromtext"("text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygonfromwkb"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygonfromwkb"("bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygonfromwkb"("bytea", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygonfromwkb"("bytea", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygonize"("extensions"."geometry"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygonize"("extensions"."geometry"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_project"("geog" "extensions"."geography", "distance" double precision, "azimuth" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_project"("geog" "extensions"."geography", "distance" double precision, "azimuth" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_quantizecoordinates"("g" "extensions"."geometry", "prec_x" integer, "prec_y" integer, "prec_z" integer, "prec_m" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_quantizecoordinates"("g" "extensions"."geometry", "prec_x" integer, "prec_y" integer, "prec_z" integer, "prec_m" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_reduceprecision"("geom" "extensions"."geometry", "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_reduceprecision"("geom" "extensions"."geometry", "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_relate"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_relate"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_relate"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_relate"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_relate"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_relate"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_relatematch"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_relatematch"("text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_removepoint"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_removepoint"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_removerepeatedpoints"("geom" "extensions"."geometry", "tolerance" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_removerepeatedpoints"("geom" "extensions"."geometry", "tolerance" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_reverse"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_reverse"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_rotate"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_rotate"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_rotate"("extensions"."geometry", double precision, "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_rotate"("extensions"."geometry", double precision, "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_rotate"("extensions"."geometry", double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_rotate"("extensions"."geometry", double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_rotatex"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_rotatex"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_rotatey"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_rotatey"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_rotatez"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_rotatez"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_scale"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_scale"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_scale"("extensions"."geometry", "extensions"."geometry", "origin" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_scale"("extensions"."geometry", "extensions"."geometry", "origin" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_scale"("extensions"."geometry", double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_scale"("extensions"."geometry", double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_scale"("extensions"."geometry", double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_scale"("extensions"."geometry", double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_scroll"("extensions"."geometry", "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_scroll"("extensions"."geometry", "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_segmentize"("geog" "extensions"."geography", "max_segment_length" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_segmentize"("geog" "extensions"."geography", "max_segment_length" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_segmentize"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_segmentize"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_seteffectivearea"("extensions"."geometry", double precision, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_seteffectivearea"("extensions"."geometry", double precision, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_setpoint"("extensions"."geometry", integer, "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_setpoint"("extensions"."geometry", integer, "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_setsrid"("geog" "extensions"."geography", "srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_setsrid"("geog" "extensions"."geography", "srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_setsrid"("geom" "extensions"."geometry", "srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_setsrid"("geom" "extensions"."geometry", "srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_sharedpaths"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_sharedpaths"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_shiftlongitude"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_shiftlongitude"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_shortestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_shortestline"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_simplify"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_simplify"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_simplify"("extensions"."geometry", double precision, boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_simplify"("extensions"."geometry", double precision, boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_simplifypolygonhull"("geom" "extensions"."geometry", "vertex_fraction" double precision, "is_outer" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_simplifypolygonhull"("geom" "extensions"."geometry", "vertex_fraction" double precision, "is_outer" boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_simplifypreservetopology"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_simplifypreservetopology"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_simplifyvw"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_simplifyvw"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_snap"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_snap"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_snaptogrid"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_snaptogrid"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_snaptogrid"("extensions"."geometry", double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_snaptogrid"("extensions"."geometry", double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_snaptogrid"("extensions"."geometry", double precision, double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_snaptogrid"("extensions"."geometry", double precision, double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_snaptogrid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision, double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_snaptogrid"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", double precision, double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_split"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_split"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_square"("size" double precision, "cell_i" integer, "cell_j" integer, "origin" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_square"("size" double precision, "cell_i" integer, "cell_j" integer, "origin" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_squaregrid"("size" double precision, "bounds" "extensions"."geometry", OUT "geom" "extensions"."geometry", OUT "i" integer, OUT "j" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_squaregrid"("size" double precision, "bounds" "extensions"."geometry", OUT "geom" "extensions"."geometry", OUT "i" integer, OUT "j" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_srid"("geog" "extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_srid"("geog" "extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_srid"("geom" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_srid"("geom" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_startpoint"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_startpoint"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_subdivide"("geom" "extensions"."geometry", "maxvertices" integer, "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_subdivide"("geom" "extensions"."geometry", "maxvertices" integer, "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_summary"("extensions"."geography"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_summary"("extensions"."geography") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_summary"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_summary"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_swapordinates"("geom" "extensions"."geometry", "ords" "cstring"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_swapordinates"("geom" "extensions"."geometry", "ords" "cstring") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_symdifference"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_symdifference"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_symmetricdifference"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_symmetricdifference"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_tileenvelope"("zoom" integer, "x" integer, "y" integer, "bounds" "extensions"."geometry", "margin" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_tileenvelope"("zoom" integer, "x" integer, "y" integer, "bounds" "extensions"."geometry", "margin" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_touches"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_touches"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_transform"("extensions"."geometry", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_transform"("extensions"."geometry", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_transform"("geom" "extensions"."geometry", "to_proj" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_transform"("geom" "extensions"."geometry", "to_proj" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_transform"("geom" "extensions"."geometry", "from_proj" "text", "to_srid" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_transform"("geom" "extensions"."geometry", "from_proj" "text", "to_srid" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_transform"("geom" "extensions"."geometry", "from_proj" "text", "to_proj" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_transform"("geom" "extensions"."geometry", "from_proj" "text", "to_proj" "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_translate"("extensions"."geometry", double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_translate"("extensions"."geometry", double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_translate"("extensions"."geometry", double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_translate"("extensions"."geometry", double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_transscale"("extensions"."geometry", double precision, double precision, double precision, double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_transscale"("extensions"."geometry", double precision, double precision, double precision, double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_triangulatepolygon"("g1" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_triangulatepolygon"("g1" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_unaryunion"("extensions"."geometry", "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_unaryunion"("extensions"."geometry", "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_union"("extensions"."geometry"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_union"("extensions"."geometry"[]) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_union"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_union"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_union"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_union"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry", "gridsize" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_voronoilines"("g1" "extensions"."geometry", "tolerance" double precision, "extend_to" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_voronoilines"("g1" "extensions"."geometry", "tolerance" double precision, "extend_to" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_voronoipolygons"("g1" "extensions"."geometry", "tolerance" double precision, "extend_to" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_voronoipolygons"("g1" "extensions"."geometry", "tolerance" double precision, "extend_to" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_within"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_within"("geom1" "extensions"."geometry", "geom2" "extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_wkbtosql"("wkb" "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_wkbtosql"("wkb" "bytea") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_wkttosql"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_wkttosql"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_wrapx"("geom" "extensions"."geometry", "wrap" double precision, "move" double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_wrapx"("geom" "extensions"."geometry", "wrap" double precision, "move" double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_x"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_x"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_xmax"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_xmax"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_xmin"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_xmin"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_y"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_y"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ymax"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ymax"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_ymin"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_ymin"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_z"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_z"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_zmax"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_zmax"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_zmflag"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_zmflag"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_zmin"("extensions"."box3d"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_zmin"("extensions"."box3d") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "try_cast_double"("inp" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."try_cast_double"("inp" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."try_cast_double"("inp" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."try_cast_double"("inp" "text") TO "dashboard_user";


--
-- Name: FUNCTION "unlockrows"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."unlockrows"("text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "updategeometrysrid"(character varying, character varying, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."updategeometrysrid"(character varying, character varying, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "updategeometrysrid"(character varying, character varying, character varying, integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."updategeometrysrid"(character varying, character varying, character varying, integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "updategeometrysrid"("catalogn_name" character varying, "schema_name" character varying, "table_name" character varying, "column_name" character varying, "new_srid_in" integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."updategeometrysrid"("catalogn_name" character varying, "schema_name" character varying, "table_name" character varying, "column_name" character varying, "new_srid_in" integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "url_decode"("data" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."url_decode"("data" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."url_decode"("data" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."url_decode"("data" "text") TO "dashboard_user";


--
-- Name: FUNCTION "url_encode"("data" "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."url_encode"("data" "bytea") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."url_encode"("data" "bytea") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."url_encode"("data" "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "verify"("token" "text", "secret" "text", "algorithm" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "extensions"."verify"("token" "text", "secret" "text", "algorithm" "text") FROM "postgres";
-- GRANT ALL ON FUNCTION "extensions"."verify"("token" "text", "secret" "text", "algorithm" "text") TO "postgres" WITH GRANT OPTION;
-- GRANT ALL ON FUNCTION "extensions"."verify"("token" "text", "secret" "text", "algorithm" "text") TO "dashboard_user";


--
-- Name: FUNCTION "get_schema_version"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "postgres";
-- GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "anon";
-- GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "authenticated";
-- GRANT ALL ON FUNCTION "graphql"."get_schema_version"() TO "service_role";


--
-- Name: FUNCTION "increment_schema_version"(); Type: ACL; Schema: graphql; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "postgres";
-- GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "anon";
-- GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "authenticated";
-- GRANT ALL ON FUNCTION "graphql"."increment_schema_version"() TO "service_role";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
-- GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
-- GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
-- GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "http_get"("url" "text", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer); Type: ACL; Schema: net; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "net"."http_get"("url" "text", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) FROM PUBLIC;
-- GRANT ALL ON FUNCTION "net"."http_get"("url" "text", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "supabase_functions_admin";
-- GRANT ALL ON FUNCTION "net"."http_get"("url" "text", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "anon";
-- GRANT ALL ON FUNCTION "net"."http_get"("url" "text", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "authenticated";
-- GRANT ALL ON FUNCTION "net"."http_get"("url" "text", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "service_role";


--
-- Name: FUNCTION "http_post"("url" "text", "body" "jsonb", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer); Type: ACL; Schema: net; Owner: postgres
--

-- REVOKE ALL ON FUNCTION "net"."http_post"("url" "text", "body" "jsonb", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) FROM PUBLIC;
-- GRANT ALL ON FUNCTION "net"."http_post"("url" "text", "body" "jsonb", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "supabase_functions_admin";
-- GRANT ALL ON FUNCTION "net"."http_post"("url" "text", "body" "jsonb", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "anon";
-- GRANT ALL ON FUNCTION "net"."http_post"("url" "text", "body" "jsonb", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "authenticated";
-- GRANT ALL ON FUNCTION "net"."http_post"("url" "text", "body" "jsonb", "params" "jsonb", "headers" "jsonb", "timeout_milliseconds" integer) TO "service_role";


--
-- Name: FUNCTION "crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_uuid" "uuid", "nonce" "bytea"); Type: ACL; Schema: pgsodium; Owner: pgsodium_keymaker
--

-- GRANT ALL ON FUNCTION "pgsodium"."crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_uuid" "uuid", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "crypto_aead_det_encrypt"("message" "bytea", "additional" "bytea", "key_uuid" "uuid", "nonce" "bytea"); Type: ACL; Schema: pgsodium; Owner: pgsodium_keymaker
--

-- GRANT ALL ON FUNCTION "pgsodium"."crypto_aead_det_encrypt"("message" "bytea", "additional" "bytea", "key_uuid" "uuid", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "crypto_aead_det_keygen"(); Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "pgsodium"."crypto_aead_det_keygen"() TO "service_role";


--
-- Name: TABLE "user_resources"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."user_resources" TO "anon";
GRANT ALL ON TABLE "public"."user_resources" TO "authenticated";
GRANT ALL ON TABLE "public"."user_resources" TO "service_role";


--
-- Name: FUNCTION "add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying, "p_sharing_scope" "public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying, "p_sharing_scope" "public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes") TO "postgres";
GRANT ALL ON FUNCTION "public"."add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying, "p_sharing_scope" "public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes") TO "anon";
GRANT ALL ON FUNCTION "public"."add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying, "p_sharing_scope" "public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes") TO "authenticated";
GRANT ALL ON FUNCTION "public"."add_user_resource"("p_user_id" "uuid", "p_resource_id" "uuid", "p_quantity" integer, "p_notes" character varying, "p_sharing_scope" "public"."sharing_scopes", "p_sharing_scope_emergency" "public"."sharing_scopes") TO "service_role";


--
-- Name: FUNCTION "authorize"("requested_permission" "public"."app_permissions"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."authorize"("requested_permission" "public"."app_permissions") TO "postgres";
GRANT ALL ON FUNCTION "public"."authorize"("requested_permission" "public"."app_permissions") TO "anon";
GRANT ALL ON FUNCTION "public"."authorize"("requested_permission" "public"."app_permissions") TO "authenticated";
GRANT ALL ON FUNCTION "public"."authorize"("requested_permission" "public"."app_permissions") TO "service_role";


--
-- Name: FUNCTION "custom_access_token"("event" "jsonb"); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION "public"."custom_access_token"("event" "jsonb") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."custom_access_token"("event" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "public"."custom_access_token"("event" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "public"."custom_access_token"("event" "jsonb") TO "service_role";
GRANT ALL ON FUNCTION "public"."custom_access_token"("event" "jsonb") TO "supabase_auth_admin";


--
-- Name: FUNCTION "delete_checklist_step_cascade"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."delete_checklist_step_cascade"() TO "anon";
GRANT ALL ON FUNCTION "public"."delete_checklist_step_cascade"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."delete_checklist_step_cascade"() TO "service_role";


--
-- Name: FUNCTION "delete_user"("user_id" "uuid"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."delete_user"("user_id" "uuid") TO "postgres";
GRANT ALL ON FUNCTION "public"."delete_user"("user_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."delete_user"("user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."delete_user"("user_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid") TO "postgres";
GRANT ALL ON FUNCTION "public"."find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."find_direct_group_between_profiles"("p_profile_a" "uuid", "p_profile_b" "uuid") TO "service_role";


--
-- Name: FUNCTION "get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean) TO "postgres";
GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean) TO "anon";
GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_current_location"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_is_emergency" boolean) TO "service_role";


--
-- Name: FUNCTION "get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean) TO "postgres";
GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean) TO "anon";
GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_nearest_resource_suppliers_by_household"("p_requester_profile_id" "uuid", "p_resource_id" "uuid", "p_is_emergency" boolean) TO "service_role";


--
-- Name: FUNCTION "get_next_group_name"("p_base_name" "text"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."get_next_group_name"("p_base_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "public"."get_next_group_name"("p_base_name" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."get_next_group_name"("p_base_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_next_group_name"("p_base_name" "text") TO "service_role";


--
-- Name: FUNCTION "get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid") TO "postgres";
GRANT ALL ON FUNCTION "public"."get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_unread_count"("p_profile_id" "uuid", "p_group_id" "uuid") TO "service_role";


--
-- Name: TABLE "point_of_interests"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."point_of_interests" TO "anon";
GRANT ALL ON TABLE "public"."point_of_interests" TO "authenticated";
GRANT ALL ON TABLE "public"."point_of_interests" TO "service_role";


--
-- Name: FUNCTION "get_visible_points_of_interest"("p_requester_profile_id" "uuid"); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."get_visible_points_of_interest"("p_requester_profile_id" "uuid") TO "postgres";
GRANT ALL ON FUNCTION "public"."get_visible_points_of_interest"("p_requester_profile_id" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."get_visible_points_of_interest"("p_requester_profile_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_visible_points_of_interest"("p_requester_profile_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "handle_reservation_status_change"(); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."handle_reservation_status_change"() TO "postgres";
GRANT ALL ON FUNCTION "public"."handle_reservation_status_change"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_reservation_status_change"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_reservation_status_change"() TO "service_role";


--
-- Name: FUNCTION "insert_checklist_steps_state_for_all_users"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."insert_checklist_steps_state_for_all_users"() TO "anon";
GRANT ALL ON FUNCTION "public"."insert_checklist_steps_state_for_all_users"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."insert_checklist_steps_state_for_all_users"() TO "service_role";


--
-- Name: FUNCTION "insert_user_checklists_for_all_users"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."insert_user_checklists_for_all_users"() TO "anon";
GRANT ALL ON FUNCTION "public"."insert_user_checklists_for_all_users"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."insert_user_checklists_for_all_users"() TO "service_role";


--
-- Name: FUNCTION "invalidate_signup_code"("input_code" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."invalidate_signup_code"("input_code" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."invalidate_signup_code"("input_code" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."invalidate_signup_code"("input_code" "text") TO "service_role";


--
-- Name: TABLE "requests"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."requests" TO "anon";
GRANT ALL ON TABLE "public"."requests" TO "authenticated";
GRANT ALL ON TABLE "public"."requests" TO "service_role";


--
-- Name: FUNCTION "reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text", "p_distance_meters" double precision); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text", "p_distance_meters" double precision) TO "postgres";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text", "p_distance_meters" double precision) TO "anon";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text", "p_distance_meters" double precision) TO "authenticated";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_notes" "text", "p_distance_meters" double precision) TO "service_role";


--
-- Name: FUNCTION "reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text", "p_distance_meters" double precision); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text", "p_distance_meters" double precision) TO "postgres";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text", "p_distance_meters" double precision) TO "anon";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text", "p_distance_meters" double precision) TO "authenticated";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v2"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_notes" "text", "p_distance_meters" double precision) TO "service_role";


--
-- Name: FUNCTION "reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text", "p_distance_meters" double precision); Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text", "p_distance_meters" double precision) TO "postgres";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text", "p_distance_meters" double precision) TO "anon";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text", "p_distance_meters" double precision) TO "authenticated";
GRANT ALL ON FUNCTION "public"."reserve_request_candidate_v3"("p_resource_id" "uuid", "p_quantity" integer, "p_request_scope" "public"."request_scope", "p_requester_profile_id" "uuid", "p_supplier_profile_id" "uuid", "p_user_resource_id" "uuid", "p_expires_at" timestamp without time zone, "p_hours_needed" integer, "p_notes" "text", "p_distance_meters" double precision) TO "service_role";


--
-- Name: FUNCTION "st_3dextent"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_3dextent"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asflatgeobuf"("anyelement"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asflatgeobuf"("anyelement") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asflatgeobuf"("anyelement", boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asflatgeobuf"("anyelement", boolean) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asflatgeobuf"("anyelement", boolean, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asflatgeobuf"("anyelement", boolean, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgeobuf"("anyelement"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgeobuf"("anyelement") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asgeobuf"("anyelement", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asgeobuf"("anyelement", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmvt"("anyelement"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmvt"("anyelement") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmvt"("anyelement", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmvt"("anyelement", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmvt"("anyelement", "text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmvt"("anyelement", "text", integer) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmvt"("anyelement", "text", integer, "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmvt"("anyelement", "text", integer, "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_asmvt"("anyelement", "text", integer, "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_asmvt"("anyelement", "text", integer, "text", "text") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clusterintersecting"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clusterintersecting"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_clusterwithin"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_clusterwithin"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_collect"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_collect"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_extent"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_extent"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_makeline"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_makeline"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_memcollect"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_memcollect"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_memunion"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_memunion"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_polygonize"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_polygonize"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_union"("extensions"."geometry"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_union"("extensions"."geometry") TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "st_union"("extensions"."geometry", double precision); Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON FUNCTION "extensions"."st_union"("extensions"."geometry", double precision) TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

-- GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "seq_schema_version"; Type: ACL; Schema: graphql; Owner: supabase_admin
--

-- GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "postgres";
-- GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "anon";
-- GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "authenticated";
-- GRANT ALL ON SEQUENCE "graphql"."seq_schema_version" TO "service_role";


--
-- Name: TABLE "decrypted_key"; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

-- GRANT ALL ON TABLE "pgsodium"."decrypted_key" TO "pgsodium_keyholder";


--
-- Name: TABLE "masking_rule"; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

-- GRANT ALL ON TABLE "pgsodium"."masking_rule" TO "pgsodium_keyholder";


--
-- Name: TABLE "mask_columns"; Type: ACL; Schema: pgsodium; Owner: supabase_admin
--

-- GRANT ALL ON TABLE "pgsodium"."mask_columns" TO "pgsodium_keyholder";


--
-- Name: TABLE "blocks"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."blocks" TO "postgres";
GRANT ALL ON TABLE "public"."blocks" TO "anon";
GRANT ALL ON TABLE "public"."blocks" TO "authenticated";
GRANT ALL ON TABLE "public"."blocks" TO "service_role";


--
-- Name: TABLE "checklist_steps"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."checklist_steps" TO "anon";
GRANT ALL ON TABLE "public"."checklist_steps" TO "authenticated";
GRANT ALL ON TABLE "public"."checklist_steps" TO "service_role";


--
-- Name: TABLE "checklist_steps_orders"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."checklist_steps_orders" TO "anon";
GRANT ALL ON TABLE "public"."checklist_steps_orders" TO "authenticated";
GRANT ALL ON TABLE "public"."checklist_steps_orders" TO "service_role";


--
-- Name: TABLE "checklist_steps_states"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."checklist_steps_states" TO "anon";
GRANT ALL ON TABLE "public"."checklist_steps_states" TO "authenticated";
GRANT ALL ON TABLE "public"."checklist_steps_states" TO "service_role";


--
-- Name: TABLE "checklists"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."checklists" TO "anon";
GRANT ALL ON TABLE "public"."checklists" TO "authenticated";
GRANT ALL ON TABLE "public"."checklists" TO "service_role";


--
-- Name: TABLE "clusters"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."clusters" TO "anon";
GRANT ALL ON TABLE "public"."clusters" TO "authenticated";
GRANT ALL ON TABLE "public"."clusters" TO "service_role";


--
-- Name: TABLE "people"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."people" TO "anon";
GRANT ALL ON TABLE "public"."people" TO "authenticated";
GRANT ALL ON TABLE "public"."people" TO "service_role";


--
-- Name: TABLE "user_captain_clusters"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."user_captain_clusters" TO "anon";
GRANT ALL ON TABLE "public"."user_captain_clusters" TO "authenticated";
GRANT ALL ON TABLE "public"."user_captain_clusters" TO "service_role";


--
-- Name: TABLE "user_roles"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."user_roles" TO "anon";
GRANT ALL ON TABLE "public"."user_roles" TO "authenticated";
GRANT ALL ON TABLE "public"."user_roles" TO "service_role";
GRANT ALL ON TABLE "public"."user_roles" TO "supabase_auth_admin";


--
-- Name: TABLE "cluster_captains_view"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."cluster_captains_view" TO "postgres";
GRANT ALL ON TABLE "public"."cluster_captains_view" TO "anon";
GRANT ALL ON TABLE "public"."cluster_captains_view" TO "authenticated";
GRANT ALL ON TABLE "public"."cluster_captains_view" TO "service_role";


--
-- Name: TABLE "frequency"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."frequency" TO "anon";
GRANT ALL ON TABLE "public"."frequency" TO "authenticated";
GRANT ALL ON TABLE "public"."frequency" TO "service_role";


--
-- Name: TABLE "group_members"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."group_members" TO "anon";
GRANT ALL ON TABLE "public"."group_members" TO "authenticated";
GRANT ALL ON TABLE "public"."group_members" TO "service_role";


--
-- Name: TABLE "groups"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."groups" TO "anon";
GRANT ALL ON TABLE "public"."groups" TO "authenticated";
GRANT ALL ON TABLE "public"."groups" TO "service_role";


--
-- Name: TABLE "households"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."households" TO "anon";
GRANT ALL ON TABLE "public"."households" TO "authenticated";
GRANT ALL ON TABLE "public"."households" TO "service_role";


--
-- Name: TABLE "message_reads"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."message_reads" TO "postgres";
GRANT ALL ON TABLE "public"."message_reads" TO "anon";
GRANT ALL ON TABLE "public"."message_reads" TO "authenticated";
GRANT ALL ON TABLE "public"."message_reads" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."messages" TO "anon";
GRANT ALL ON TABLE "public"."messages" TO "authenticated";
GRANT ALL ON TABLE "public"."messages" TO "service_role";


--
-- Name: TABLE "operational_events"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."operational_events" TO "anon";
GRANT ALL ON TABLE "public"."operational_events" TO "authenticated";
GRANT ALL ON TABLE "public"."operational_events" TO "service_role";


--
-- Name: TABLE "people_groups"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."people_groups" TO "anon";
GRANT ALL ON TABLE "public"."people_groups" TO "authenticated";
GRANT ALL ON TABLE "public"."people_groups" TO "service_role";


--
-- Name: TABLE "point_of_interest_types"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."point_of_interest_types" TO "anon";
GRANT ALL ON TABLE "public"."point_of_interest_types" TO "authenticated";
GRANT ALL ON TABLE "public"."point_of_interest_types" TO "service_role";


--
-- Name: TABLE "resource_reservations"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."resource_reservations" TO "postgres";
GRANT ALL ON TABLE "public"."resource_reservations" TO "anon";
GRANT ALL ON TABLE "public"."resource_reservations" TO "authenticated";
GRANT ALL ON TABLE "public"."resource_reservations" TO "service_role";


--
-- Name: TABLE "resource_subtype_tags"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."resource_subtype_tags" TO "anon";
GRANT ALL ON TABLE "public"."resource_subtype_tags" TO "authenticated";
GRANT ALL ON TABLE "public"."resource_subtype_tags" TO "service_role";


--
-- Name: TABLE "resource_tags"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."resource_tags" TO "anon";
GRANT ALL ON TABLE "public"."resource_tags" TO "authenticated";
GRANT ALL ON TABLE "public"."resource_tags" TO "service_role";


--
-- Name: TABLE "resource_types"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."resource_types" TO "anon";
GRANT ALL ON TABLE "public"."resource_types" TO "authenticated";
GRANT ALL ON TABLE "public"."resource_types" TO "service_role";


--
-- Name: TABLE "resources"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."resources" TO "anon";
GRANT ALL ON TABLE "public"."resources" TO "authenticated";
GRANT ALL ON TABLE "public"."resources" TO "service_role";


--
-- Name: TABLE "resources_cv"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."resources_cv" TO "anon";
GRANT ALL ON TABLE "public"."resources_cv" TO "authenticated";
GRANT ALL ON TABLE "public"."resources_cv" TO "service_role";


--
-- Name: TABLE "role_permissions"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."role_permissions" TO "anon";
GRANT ALL ON TABLE "public"."role_permissions" TO "authenticated";
GRANT ALL ON TABLE "public"."role_permissions" TO "service_role";


--
-- Name: TABLE "signup_codes"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."signup_codes" TO "anon";
GRANT ALL ON TABLE "public"."signup_codes" TO "authenticated";
GRANT ALL ON TABLE "public"."signup_codes" TO "service_role";


--
-- Name: TABLE "user_checklists"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."user_checklists" TO "anon";
GRANT ALL ON TABLE "public"."user_checklists" TO "authenticated";
GRANT ALL ON TABLE "public"."user_checklists" TO "service_role";


--
-- Name: TABLE "user_profiles"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."user_profiles" TO "anon";
GRANT ALL ON TABLE "public"."user_profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."user_profiles" TO "service_role";


--
-- Name: TABLE "user_resources_view"; Type: ACL; Schema: public; Owner: supabase_admin
--

GRANT ALL ON TABLE "public"."user_resources_view" TO "postgres";
GRANT ALL ON TABLE "public"."user_resources_view" TO "anon";
GRANT ALL ON TABLE "public"."user_resources_view" TO "authenticated";
GRANT ALL ON TABLE "public"."user_resources_view" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "postgres";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "anon";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "authenticated";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "postgres";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "anon";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "authenticated";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "postgres";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "anon";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "authenticated";
-- ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES  TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

-- CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
--          WHEN TAG IN ('DROP EXTENSION')
--    EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


-- ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

-- CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
--          WHEN TAG IN ('CREATE EXTENSION')
--    EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


-- ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

-- CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
--          WHEN TAG IN ('CREATE FUNCTION')
--    EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


-- ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

-- CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
--          WHEN TAG IN ('CREATE EXTENSION')
--    EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


-- ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "postgres";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

-- CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
--    EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


-- ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

-- CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
--    EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


-- ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

-- dumping roles

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

ALTER ROLE "anon" SET "statement_timeout" TO '3s';

ALTER ROLE "authenticated" SET "statement_timeout" TO '8s';

ALTER ROLE "authenticator" SET "statement_timeout" TO '8s';

-- dumping data
SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Ubuntu 15.1-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.5 (Ubuntu 15.5-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: frequency; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."frequency" ("id", "name", "num_days") VALUES
	('b8cfc85f-4be0-422a-b6c9-2c13d747138e', 'Monthly', 30),
	('97a79d82-264c-46ab-9639-0cee8cebce10', 'Yearly', 365);


--
-- Data for Name: point_of_interest_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."point_of_interest_types" ("name", "icon", "category") VALUES
	('emergency hub', 'kit-medical', 'emergency_safety'),
	('hospital', 'hospital', 'medical'),
	('school', 'graduation-cap', 'education'),
	('library', 'book', 'education'),
	('community center', 'houzz', 'community_civic'),
	('church', 'hands-praying', 'community_civic'),
	('meeting place', 'flag', 'personal_other'),
	('other', 'atom', 'personal_other'),
	('person', 'user', 'personal_other'),
	('cluster meeting point', 'flag-checkered', 'emergency_safety'),
	('cluster captain', 'user-shield', 'emergency_safety'),
	('clinic', 'kit-medical', 'community_civic'),
	('fire-department', 'house-fire', 'community_civic'),
	('foodbank', 'bread-slice', 'community_civic'),
	('hall', 'landmark', 'community_civic'),
	('museum', 'landmark', 'education'),
	('park', 'tree', 'nature_outdoor'),
	('store', 'store', 'business_economic'),
	('utility', 'water', 'community_civic'),
	('visitor-service', 'person-shelter', 'personal_other');


--
-- Data for Name: resource_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."resource_types" ("id", "name", "description") VALUES
	('bf8ad46c-9a8a-4b50-b51c-71897b7f4544', 'Durable', 'These are physical instruments and devices that help you perform specific tasks, such as repairs, navigation, or building shelters during an emergency.'),
	('ea7419be-e86e-4251-a6c7-65e8953dce6b', 'Consumable', 'These are essential supplies, including food, water, and personal hygiene products that are consumed or used up during an emergency.'),
	('0a2e1d1d-70af-48da-9245-41eb5e151492', 'Skill', 'These are the skills and knowledge that individuals or groups should possess or develop in preparation for an emergency.');


--
-- Data for Name: resources_cv; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."resources_cv" ("id", "name", "description", "unit") VALUES
	('6651d6a5-6182-4f85-a573-db5f1c55ab03', 'Water purification tablets', 'To treat water if supplies run out or are contaminated', 'Unknown'),
	('dd9f4998-bf9b-4137-a107-5a2d1b259594', 'Fire extinguisher', 'Class ABC fire extinguisher for general fire safety', 'Unknown'),
	('22ae4ed0-bfc2-4b7c-a43e-9dc27bcc3943', 'Hammer', 'For basic repairs and shelter construction', 'Unknown'),
	('ac383bd6-d037-4bd3-a656-86670d62c073', 'Chain saw', 'For cutting down large trees or clearing debris if trained', 'Unknown'),
	('43788c13-22ff-4cde-ac05-7b2c4d18e35e', 'Tent', 'For shelter in case of evacuation', 'Unknown'),
	('234c0650-d307-4490-a0c8-1fc7f672026b', 'Screwdriver set', 'For minor fixes and adjustments', 'Unknown'),
	('72dbfee4-8008-438e-b0ed-fc6a488616a6', 'Personal hygiene products', 'Including soap, hand sanitizer, wet wipes, feminine hygiene products, and/or diapers', 'Unknown'),
	('c212ddc4-ffc4-4470-b1eb-af86fdecf0b4', 'Flashlight', 'Flashlight, preferably with extra batteries', 'Unknown'),
	('60d7efb6-bbd5-4764-9fa1-a0dfc6f5b222', 'Emergency blanket', 'To keep warm in cold weather', 'Unknown'),
	('d42fa21c-fb9c-459b-a3ae-8c682b90072e', 'Can opener', 'To open canned food', 'Unknown'),
	('2be173a6-b8c0-41e4-8149-9f73b6559329', 'First-aid kit', 'Including bandages, antiseptics, painkillers, tweezers, and/or burn ointments', 'Unknown'),
	('4c480fad-0b25-40bf-90ef-3a8e0a2232d4', 'Water', 'One gallon', 'Gallons'),
	('1bc7aaad-f2d5-4394-a83f-13c952ca12f1', 'Non-perishable food', 'Single serving of ready-to-eat canned goods, protein bars, cereals, nuts, etc', 'Servings'),
	('8448da45-b66e-4b2b-b182-c665bc951b86', 'Vehicle maintenance', 'Basic ability to troubleshoot or repair vehicle issues such as changing tires or jump-starting', 'People'),
	('d1c4ec87-92e5-4e86-a883-c7138b55f07a', 'Ham radio operation', 'Ability to use amateur radios for communication if cellular networks fail', 'People'),
	('e9f554a7-4f14-48b5-bbac-21d437740fa7', 'Fire safety and evacuation', 'Knowledge of how to extinguish small fires and follow evacuation routes', 'People'),
	('7afce1ab-6d6c-4a38-9564-0125dc75c4fa', 'First-aid knowledge', 'Ability to administer basic medical care and CPR', 'People'),
	('08bd6058-6e76-4a5d-b378-7b021d1c19ba', 'Search and rescue basics', 'Ability to assist in locating missing persons or help in local emergency operations', 'People');


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."resources" ("resource_cv_id", "resource_type_id", "notes", "qty_needed", "qty_available") VALUES
	('4c480fad-0b25-40bf-90ef-3a8e0a2232d4', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('1bc7aaad-f2d5-4394-a83f-13c952ca12f1', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('d42fa21c-fb9c-459b-a3ae-8c682b90072e', 'bf8ad46c-9a8a-4b50-b51c-71897b7f4544', NULL, 0, 0),
	('2be173a6-b8c0-41e4-8149-9f73b6559329', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('72dbfee4-8008-438e-b0ed-fc6a488616a6', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('c212ddc4-ffc4-4470-b1eb-af86fdecf0b4', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('60d7efb6-bbd5-4764-9fa1-a0dfc6f5b222', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('6651d6a5-6182-4f85-a573-db5f1c55ab03', 'ea7419be-e86e-4251-a6c7-65e8953dce6b', NULL, 0, 0),
	('dd9f4998-bf9b-4137-a107-5a2d1b259594', 'bf8ad46c-9a8a-4b50-b51c-71897b7f4544', NULL, 0, 0),
	('22ae4ed0-bfc2-4b7c-a43e-9dc27bcc3943', 'bf8ad46c-9a8a-4b50-b51c-71897b7f4544', NULL, 0, 0),
	('234c0650-d307-4490-a0c8-1fc7f672026b', 'bf8ad46c-9a8a-4b50-b51c-71897b7f4544', NULL, 0, 0),
	('ac383bd6-d037-4bd3-a656-86670d62c073', 'bf8ad46c-9a8a-4b50-b51c-71897b7f4544', NULL, 0, 0),
	('43788c13-22ff-4cde-ac05-7b2c4d18e35e', 'bf8ad46c-9a8a-4b50-b51c-71897b7f4544', NULL, 0, 0),
	('7afce1ab-6d6c-4a38-9564-0125dc75c4fa', '0a2e1d1d-70af-48da-9245-41eb5e151492', NULL, 0, 0),
	('e9f554a7-4f14-48b5-bbac-21d437740fa7', '0a2e1d1d-70af-48da-9245-41eb5e151492', NULL, 0, 0),
	('08bd6058-6e76-4a5d-b378-7b021d1c19ba', '0a2e1d1d-70af-48da-9245-41eb5e151492', NULL, 0, 0),
	('d1c4ec87-92e5-4e86-a883-c7138b55f07a', '0a2e1d1d-70af-48da-9245-41eb5e151492', NULL, 0, 0),
	('8448da45-b66e-4b2b-b182-c665bc951b86', '0a2e1d1d-70af-48da-9245-41eb5e151492', NULL, 0, 0);


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO "public"."role_permissions" ("id", "role", "permission") VALUES
	('bd4ea14a-60e2-4bb8-b11a-94595835aa95', 'admin', 'operational_event_read'),
	('0e211a67-d848-4535-874b-3719bf6b7639', 'com_admin', 'operational_event_read'),
	('17b7a86c-5602-4700-8d33-7faf7a21df40', 'subcom_agent', 'operational_event_read'),
	('7d50b35b-b2ff-462d-9992-56966b567471', 'admin', 'operational_event_create'),
	('01431af7-ba11-4b89-8118-b081c8b01397', 'com_admin', 'operational_event_create');


--
-- PostgreSQL database dump complete
--

RESET ALL;
